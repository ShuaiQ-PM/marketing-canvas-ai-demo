import { useEffect, useMemo, useState } from "react";
import type { AiHostingModel } from "@chatai/contracts";
import {
  Add01Icon,
  ArrowExpand02Icon,
  Delete01Icon,
  ExpandIcon,
  InformationCircleIcon,
  MinusSignIcon,
  Settings03Icon,
} from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import { AiModelSelect } from "@/pages/chat/ai-hosting/ai-model-select";
import { listAiHostingModels } from "@/pages/chat/ai-hosting/agent-service";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  SegmentedControl,
  SegmentedControlItem,
} from "@/components/ui/segmented-control";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Spinner } from "@/components/ui/spinner";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import {
  SettingWorkspaceEditorContent,
  useSettingWorkspace,
} from "../../panels/setting-workspace";
import { WorkflowSettingsSection } from "../../panels/settings-section";
import type { NodeSettingsProps } from "../../panels/types";
import type {
  LlmNodeData,
  WorkflowLlmInputParameter,
  WorkflowLlmOutputConfig,
  WorkflowLlmOutputField,
  WorkflowLlmOutputFieldType,
  WorkflowVariableContentSegment,
  WorkflowVariableDefinition,
} from "../../types";
import { WorkflowLiteralOrVariableInput } from "../../workflow-literal-or-variable-input";
import { getAvailableLlmInputVariablesForNode } from "../../workflow-variables";
import {
  downgradeVariableContentSelector,
  variableContentEqual,
} from "../variable-content/content";
import { VariableContentEditor } from "../variable-content/editor";
import { LlmTestWorkspace } from "./test-workspace";
import {
  LLM_IDENTIFIER_PATTERN,
  LLM_INPUT_MAX_COUNT,
  LLM_INPUT_NAME_MAX_LENGTH,
  LLM_OUTPUT_DESCRIPTION_MAX_LENGTH,
  LLM_OUTPUT_FIELD_MAX_COUNT,
  LLM_OUTPUT_NAME_MAX_LENGTH,
  LLM_PROMPT_MAX_LENGTH,
  createLlmInputParameter,
  createLlmOutputField,
  getLlmInputSelector,
  getLlmInputVariables,
  getLlmMetric,
  getLlmStatus,
  getLlmSystemPromptVariables,
  normalizeLlmInputs,
  normalizeLlmModelId,
  normalizeLlmModelSnapshot,
  normalizeLlmOutput,
  normalizeLlmPrompt,
  normalizeLlmReasoningEffort,
} from "./config";
import type { LlmReasoningEffort } from "./config";

const outputFormatLabels: Record<WorkflowLlmOutputConfig["format"], string> = {
  text: "Text",
  markdown: "Markdown",
  json: "JSON",
};

const outputFormatOrder: WorkflowLlmOutputConfig["format"][] = ["text", "markdown", "json"];

const outputTypeLabels: Record<WorkflowLlmOutputFieldType, string> = {
  boolean: "Boolean",
  number: "Number",
  string: "String",
};

export function LlmConfig({
  edges,
  node,
  nodes,
  onNodeChange,
  resources,
  testContext,
}: NodeSettingsProps<"llm">) {
  const [models, setModels] = useState<AiHostingModel[]>([]);
  const [modelsLoading, setModelsLoading] = useState(true);
  const [modelsError, setModelsError] = useState(false);
  const settingWorkspace = useSettingWorkspace();
  const systemPromptEditorId = `${node.id}:system-prompt`;
  const userPromptEditorId = `${node.id}:user-prompt`;
  const expandedPrompt = settingWorkspace.activeEditor?.id === systemPromptEditorId
    ? "system"
    : settingWorkspace.activeEditor?.id === userPromptEditorId
      ? "user"
      : null;
  const inputs = normalizeLlmInputs(node.data.inputs);
  const systemPrompt = normalizeLlmPrompt(node.data.systemPrompt);
  const userPrompt = normalizeLlmPrompt(node.data.userPrompt);
  const output = normalizeLlmOutput(node.data.output);
  const modelId = normalizeLlmModelId(node.data.modelId);
  const reasoningEffort = normalizeLlmReasoningEffort(node.data.reasoningEffort);
  const selectedModel = models.find((model) => model.id === modelId);
  const thinkingEnabled = reasoningEffort !== "minimal";
  const thinkingDepth = reasoningEffort;
  const inputVariables = useMemo(() => getLlmInputVariables(inputs), [inputs]);
  const systemPromptVariables = useMemo(() => getLlmSystemPromptVariables(inputs), [inputs]);
  const availableInputValues = useMemo(() =>
    getAvailableLlmInputVariablesForNode(
      node.id,
      nodes,
      edges,
      resources?.customFields?.fields,
    ),
  [edges, node.id, nodes, resources?.customFields?.fields]);

  useEffect(() => {
    let cancelled = false;

    async function loadModels() {
      setModelsLoading(true);
      setModelsError(false);
      try {
        const response = await listAiHostingModels();
        if (!cancelled) setModels(response.models);
      }
      catch {
        if (!cancelled) setModelsError(true);
      }
      finally {
        if (!cancelled) setModelsLoading(false);
      }
    }

    void loadModels();
    return () => {
      cancelled = true;
    };
  }, []);

  const updateConfig = (patch: Partial<Pick<
    LlmNodeData,
    "inputs" | "modelId" | "modelLabel" | "modelName" | "output" | "reasoningEffort" | "systemPrompt" | "userPrompt"
  >>) => {
    const nextData = {
      inputs: patch.inputs ?? inputs,
      modelId: patch.modelId ?? modelId,
      reasoningEffort: patch.reasoningEffort ?? reasoningEffort,
      modelLabel: patch.modelLabel !== undefined
        ? patch.modelLabel
        : normalizeLlmModelSnapshot(node.data.modelLabel),
      modelName: patch.modelName !== undefined
        ? patch.modelName
        : normalizeLlmModelSnapshot(node.data.modelName),
      output: patch.output ?? output,
      systemPrompt: patch.systemPrompt ?? systemPrompt,
      userPrompt: patch.userPrompt ?? userPrompt,
    };
    onNodeChange({
      ...patch,
      metric: getLlmMetric(nextData),
      status: getLlmStatus(nextData),
    });
  };

  const updateSystemPrompt = (nextPrompt: WorkflowVariableContentSegment[]) => {
    if (!variableContentEqual(systemPrompt, nextPrompt)) {
      updateConfig({ systemPrompt: nextPrompt });
    }
  };

  const updateUserPrompt = (nextPrompt: WorkflowVariableContentSegment[]) => {
    if (!variableContentEqual(userPrompt, nextPrompt)) {
      updateConfig({ userPrompt: nextPrompt });
    }
  };

  return (
    <>
      <WorkflowSettingsSection
        actions={modelsLoading ? (
            <span className="flex h-5 items-center gap-1.5 text-xs text-muted-foreground" role="status">
              <Spinner size={14} />
              正在加载
            </span>
        ) : undefined}
        title={(
          <>
            模型<span aria-hidden="true" className="ml-0.5 text-destructive">*</span>
          </>
        )}
      >
        <div className="flex items-center gap-2">
          <AiModelSelect
            ariaLabel="模型"
            disabled={modelsLoading || modelsError}
            models={models}
            onValueChange={(nextModelId) => {
              const model = models.find((item) => item.id === nextModelId);
              if (!model) return;
              updateConfig({
                modelId: model.id,
                modelLabel: model.label,
                modelName: model.model,
              });
            }}
            placeholder="请选择模型"
            unavailableModel={modelId && !selectedModel ? {
              label: normalizeLlmModelSnapshot(node.data.modelLabel) ?? "原模型不可用",
              model: normalizeLlmModelSnapshot(node.data.modelName) ?? modelId,
            } : undefined}
            unavailableModelId={modelId && !modelsLoading ? modelId : undefined}
            value={modelId}
          />
          <Popover modal={false}>
            <PopoverTrigger asChild>
              <Button
                aria-label="深度思考设置"
                className="size-9 shrink-0 p-0 text-muted-foreground hover:text-foreground"
                disabled={!selectedModel || modelsLoading || modelsError}
                size="sm"
                type="button"
                variant="ghost"
              >
                <HugeiconsIcon icon={Settings03Icon} size={18} strokeWidth={1.8} />
              </Button>
            </PopoverTrigger>
            <PopoverContent
              align="end"
              aria-label="深度思考设置"
              className="w-[18rem] p-4"
              onInteractOutside={preventThinkingSelectDismiss}
              onPointerDownOutside={preventThinkingSelectDismiss}
              role="dialog"
              sideOffset={8}
            >
              <ThinkingSettings
                depth={thinkingDepth}
                enabled={thinkingEnabled}
                onDepthChange={(value) => updateConfig({ reasoningEffort: value })}
                onEnabledChange={(enabled) => updateConfig({
                  reasoningEffort: enabled
                    ? thinkingDepth === "minimal" ? "medium" : thinkingDepth
                    : "minimal",
                })}
              />
            </PopoverContent>
          </Popover>
        </div>
        {modelsError ? (
          <p className="text-xs text-destructive" role="alert">模型加载失败</p>
        ) : null}
      </WorkflowSettingsSection>

      <WorkflowSettingsSection
        actions={(
          <IconButton
            ariaLabel="添加输入参数"
            disabled={inputs.length >= LLM_INPUT_MAX_COUNT}
            icon={Add01Icon}
            onClick={() => updateConfig({ inputs: [...inputs, createLlmInputParameter(inputs)] })}
            tooltip="添加参数"
          />
        )}
        title="输入"
      >
        {inputs.length ? (
          <div className="space-y-2.5">
            <div className="grid grid-cols-[minmax(0,0.7fr)_minmax(0,1.3fr)_2rem] gap-2 px-0.5 text-xs text-muted-foreground">
              <span>参数名</span>
              <span>参数值</span>
            </div>
            {inputs.map((input) => (
              <LlmInputRow
                availableVariables={availableInputValues}
                input={input}
                inputs={inputs}
                key={input.id}
                onChange={(nextInput) => updateConfig({
                  inputs: inputs.map((item) => item.id === input.id ? nextInput : item),
                })}
                onDelete={() => {
                  const fallbackText = `{{${input.name.trim() || "参数"}}}`;
                  const selector = getLlmInputSelector(input.id);
                  updateConfig({
                    inputs: inputs.filter((item) => item.id !== input.id),
                    systemPrompt: downgradeVariableContentSelector(
                      systemPrompt,
                      selector,
                      fallbackText,
                    ),
                    userPrompt: downgradeVariableContentSelector(
                      userPrompt,
                      selector,
                      fallbackText,
                    ),
                  });
                }}
              />
            ))}
          </div>
        ) : (
          <p className="py-2 text-sm text-muted-foreground">暂无输入参数</p>
        )}
      </WorkflowSettingsSection>

      <PromptSection
        ariaLabel="系统提示词"
        inputVariables={systemPromptVariables}
        onChange={updateSystemPrompt}
        onExpand={() => settingWorkspace.openEditor({ id: systemPromptEditorId, title: "系统提示词" })}
        placeholder="请输入系统提示词"
        readOnly={expandedPrompt === "system"}
        required
        segments={systemPrompt}
        title="系统提示词"
      />
      <PromptSection
        ariaLabel="用户提示词"
        inputVariables={inputVariables}
        onChange={updateUserPrompt}
        onExpand={() => settingWorkspace.openEditor({ id: userPromptEditorId, title: "用户提示词" })}
        placeholder="请输入用户提示词"
        readOnly={expandedPrompt === "user"}
        segments={userPrompt}
        title="用户提示词"
      />

      <OutputSection
        onChange={(nextOutput) => updateConfig({ output: nextOutput })}
        output={output}
      />

      {expandedPrompt ? (
        <ExpandedPromptEditor
          ariaLabel={expandedPrompt === "system" ? "系统提示词" : "用户提示词"}
          editorId={expandedPrompt === "system" ? systemPromptEditorId : userPromptEditorId}
          inputVariables={expandedPrompt === "system" ? systemPromptVariables : inputVariables}
          onChange={expandedPrompt === "system" ? updateSystemPrompt : updateUserPrompt}
          placeholder={expandedPrompt === "system" ? "请输入系统提示词" : "请输入用户提示词"}
          segments={expandedPrompt === "system" ? systemPrompt : userPrompt}
        />
      ) : null}
      {testContext ? <LlmTestWorkspace node={node} testContext={testContext} /> : null}
    </>
  );
}

type ThinkingDepth = LlmReasoningEffort;

function preventThinkingSelectDismiss(event: Event) {
  const target = event.target;

  if (target instanceof Element && target.closest('[role="listbox"]')) {
    event.preventDefault();
  }
}

function ThinkingSettings({
  depth,
  enabled,
  onDepthChange,
  onEnabledChange,
}: {
  depth: ThinkingDepth;
  enabled: boolean;
  onDepthChange: (value: ThinkingDepth) => void;
  onEnabledChange: (value: boolean) => void;
}) {
  return (
    <div className="space-y-4">
      <h3 className="text-base font-semibold text-foreground">深度思考</h3>
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-4">
          <span className="text-sm text-muted-foreground">深度思考开关</span>
          <Select
            onValueChange={(value) => onEnabledChange(value === "enabled")}
            value={enabled ? "enabled" : "disabled"}
          >
            <SelectTrigger aria-label="深度思考开关" className="h-8 w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="disabled">关闭</SelectItem>
              <SelectItem value="enabled">开启</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="text-sm text-muted-foreground">深度思考程度</span>
          <Select
            onValueChange={(value) => {
              const nextDepth = normalizeLlmReasoningEffort(value);
              onDepthChange(nextDepth);
            }}
            value={depth}
          >
            <SelectTrigger aria-label="深度思考程度" className="h-8 w-24">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="minimal">关闭</SelectItem>
              <SelectItem value="low">低</SelectItem>
              <SelectItem value="medium">中</SelectItem>
              <SelectItem value="high">高</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}

function LlmInputRow({
  availableVariables,
  input,
  inputs,
  onChange,
  onDelete,
}: {
  availableVariables: WorkflowVariableDefinition[];
  input: WorkflowLlmInputParameter;
  inputs: WorkflowLlmInputParameter[];
  onChange: (input: WorkflowLlmInputParameter) => void;
  onDelete: () => void;
}) {
  const nameDuplicate = Boolean(input.name.trim()) && inputs.some((item) =>
    item.id !== input.id && item.name.trim() === input.name.trim());
  const nameInvalid = Boolean(input.name) && (!LLM_IDENTIFIER_PATTERN.test(input.name)
    || input.name.length > LLM_INPUT_NAME_MAX_LENGTH
    || nameDuplicate);

  return (
    <div className="grid grid-cols-[minmax(0,0.7fr)_minmax(0,1.3fr)_2rem] items-start gap-2">
      <Input
        aria-label="输入参数名"
        aria-invalid={nameInvalid}
        className={cn("h-9 min-w-0 px-3 text-xs", nameInvalid && "border-destructive")}
        maxLength={LLM_INPUT_NAME_MAX_LENGTH}
        onChange={(event) => onChange({ ...input, name: event.target.value })}
        placeholder="参数名"
        value={input.name}
      />
      <WorkflowLiteralOrVariableInput
        ariaLabel={`${input.name || "输入参数"}的值`}
        clearVariableAriaLabel="改为固定文本"
        customFieldVisibility="all"
        onChange={(value) => onChange({ ...input, value })}
        placeholder="输入或引用变量"
        value={input.value}
        variables={availableVariables}
      />
      <Button
        aria-label="删除输入参数"
        className="size-8 p-0 text-muted-foreground hover:text-destructive"
        onClick={onDelete}
        size="sm"
        type="button"
        variant="ghost"
      >
        <HugeiconsIcon icon={Delete01Icon} size={14} strokeWidth={1.8} />
      </Button>
    </div>
  );
}

function PromptSection({
  ariaLabel,
  inputVariables,
  onChange,
  onExpand,
  placeholder,
  readOnly,
  required = false,
  segments,
  title,
}: {
  ariaLabel: string;
  inputVariables: WorkflowVariableDefinition[];
  onChange: (segments: WorkflowVariableContentSegment[]) => void;
  onExpand: () => void;
  placeholder: string;
  readOnly: boolean;
  required?: boolean;
  segments: WorkflowVariableContentSegment[];
  title: string;
}) {
  return (
    <WorkflowSettingsSection
      actions={(
        <IconButton
          ariaLabel={`全屏编辑${title}`}
          icon={ArrowExpand02Icon}
          onClick={onExpand}
          tooltip="全屏编辑"
        />
      )}
      contentClassName="space-y-0.5"
      title={(
        <>
          {title}
          {required ? <span aria-hidden="true" className="ml-0.5 text-destructive">*</span> : null}
        </>
      )}
    >
      <VariableContentEditor
        ariaLabel={ariaLabel}
        customFieldVisibility="hidden"
        maxLength={LLM_PROMPT_MAX_LENGTH}
        onChange={onChange}
        placeholder={placeholder}
        readOnly={readOnly}
        segments={segments}
        variables={inputVariables}
      />
    </WorkflowSettingsSection>
  );
}

function ExpandedPromptEditor({
  ariaLabel,
  editorId,
  inputVariables,
  onChange,
  placeholder,
  segments,
}: {
  ariaLabel: string;
  editorId: string;
  inputVariables: WorkflowVariableDefinition[];
  onChange: (segments: WorkflowVariableContentSegment[]) => void;
  placeholder: string;
  segments: WorkflowVariableContentSegment[];
}) {
  return (
    <SettingWorkspaceEditorContent id={editorId}>
      <div className="flex min-h-0 flex-1 px-4 pb-4">
        <VariableContentEditor
          ariaLabel={`${ariaLabel}展开编辑`}
          className="flex min-h-0 flex-1 flex-col"
          contentEditableClassName="h-full min-h-full overflow-y-auto"
          customFieldVisibility="hidden"
          editorClassName="min-h-0 flex-1 overflow-y-auto"
          maxLength={LLM_PROMPT_MAX_LENGTH}
          onChange={onChange}
          placeholder={placeholder}
          segments={segments}
          variables={inputVariables}
        />
      </div>
    </SettingWorkspaceEditorContent>
  );
}

function OutputSection({
  onChange,
  output,
}: {
  onChange: (output: WorkflowLlmOutputConfig) => void;
  output: WorkflowLlmOutputConfig;
}) {
  const fields = output.format === "json" ? output.fields : [output.field];

  const changeFormat = (format: WorkflowLlmOutputConfig["format"]) => {
    const firstField = fields[0] ?? createLlmOutputField([], { name: "output" });
    if (format === "json") {
      onChange({
        fields: fields.length ? fields : [firstField],
        format: "json",
      });
      return;
    }
    onChange({
      field: { ...firstField, type: "string" },
      format,
    });
  };

  return (
    <WorkflowSettingsSection
      actions={(
        <SegmentedControl
          aria-label="输出格式"
          className="h-9 rounded-full p-1"
          onValueChange={(format) => {
            if (format === "text" || format === "markdown" || format === "json") {
              changeFormat(format);
            }
          }}
          type="single"
          value={output.format}
        >
          {outputFormatOrder.map((format) => (
            <SegmentedControlItem
              className="h-7 w-auto rounded-full px-3 text-xs font-medium data-[state=on]:bg-foreground data-[state=on]:text-background"
              key={format}
              value={format}
            >
              {outputFormatLabels[format]}
              {format === "json" ? <JsonOutputFormatHint /> : null}
            </SegmentedControlItem>
          ))}
        </SegmentedControl>
      )}
      contentClassName="space-y-3"
      title="输出"
    >

      <div className="grid grid-cols-[minmax(0,1fr)_5rem_4.125rem] gap-2 px-0.5 text-xs text-muted-foreground">
        <span>变量名</span>
        <span>参数类型</span>
      </div>

      {output.format === "json" ? (
        <div className="space-y-3">
          {output.fields.map((field) => (
            <JsonOutputFieldRow
              field={field}
              fields={output.fields}
              key={field.id}
              onChange={(nextField) => onChange({
                fields: output.fields.map((item) => item.id === field.id ? nextField : item),
                format: "json",
              })}
              onDelete={() => onChange({
                fields: output.fields.filter((item) => item.id !== field.id),
                format: "json",
              })}
            />
          ))}
          <button
            className="text-sm text-primary disabled:cursor-not-allowed disabled:opacity-50"
            disabled={output.fields.length >= LLM_OUTPUT_FIELD_MAX_COUNT}
            onClick={() => onChange({
              fields: [...output.fields, createLlmOutputField(output.fields)],
              format: "json",
            })}
            type="button"
          >
            + 添加字段
          </button>
        </div>
      ) : (
        <SingleOutputField
          field={output.field}
          onChange={(field) => onChange({ field: { ...field, type: "string" }, format: output.format })}
        />
      )}
    </WorkflowSettingsSection>
  );
}

function SingleOutputField({
  field,
  onChange,
}: {
  field: WorkflowLlmOutputField;
  onChange: (field: WorkflowLlmOutputField) => void;
}) {
  const [descriptionExpanded, setDescriptionExpanded] = useState(false);

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[minmax(0,1fr)_5rem_4.125rem] items-start gap-2">
        <IdentifierInput
          ariaLabel="输出变量名"
          maxLength={LLM_OUTPUT_NAME_MAX_LENGTH}
          onChange={(name) => onChange({ ...field, name })}
          value={field.name}
        />
        <div className="flex h-9 items-center rounded-[8px] bg-secondary px-3 text-xs text-muted-foreground">
          String
        </div>
        <div className="flex items-center gap-0.5">
          <IconButton
            ariaExpanded={descriptionExpanded}
            ariaLabel={descriptionExpanded ? "收起输出描述" : "展开输出描述"}
            className={descriptionExpanded ? "bg-accent text-foreground" : undefined}
            icon={ExpandIcon}
            onClick={() => setDescriptionExpanded((expanded) => !expanded)}
            tooltip={descriptionExpanded ? "收起描述" : "展开描述"}
          />
          <IconButton
            ariaLabel="删除输出参数"
            className="text-muted-foreground hover:text-destructive"
            disabled
            icon={MinusSignIcon}
            tooltip="删除参数"
          />
        </div>
      </div>
      {descriptionExpanded ? (
        <Input
          aria-label="输出描述"
          className="h-9 text-xs"
          maxLength={LLM_OUTPUT_DESCRIPTION_MAX_LENGTH}
          onChange={(event) => onChange({ ...field, description: event.target.value })}
          placeholder="请输入输出描述"
          value={field.description}
        />
      ) : null}
    </div>
  );
}

function JsonOutputFieldRow({
  field,
  fields,
  onChange,
  onDelete,
}: {
  field: WorkflowLlmOutputField;
  fields: WorkflowLlmOutputField[];
  onChange: (field: WorkflowLlmOutputField) => void;
  onDelete: () => void;
}) {
  const [descriptionExpanded, setDescriptionExpanded] = useState(false);
  const nameDuplicate = Boolean(field.name.trim()) && fields.some((item) =>
    item.id !== field.id && item.name.trim() === field.name.trim());
  const nameInvalid = Boolean(field.name) && (!LLM_IDENTIFIER_PATTERN.test(field.name)
    || field.name.length > LLM_OUTPUT_NAME_MAX_LENGTH
    || nameDuplicate);

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-[minmax(0,1fr)_5rem_4.125rem] items-start gap-2">
        <Input
          aria-label="JSON 字段名"
          aria-invalid={nameInvalid}
          className={cn("h-9 text-xs", nameInvalid && "border-destructive")}
          maxLength={LLM_OUTPUT_NAME_MAX_LENGTH}
          onChange={(event) => onChange({ ...field, name: event.target.value })}
          placeholder="字段名"
          value={field.name}
        />
        <Select
          onValueChange={(type) => onChange({ ...field, type: type as WorkflowLlmOutputFieldType })}
          value={field.type}
        >
          <SelectTrigger aria-label={`${field.name || "JSON 字段"}类型`} className="h-9 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {(Object.keys(outputTypeLabels) as WorkflowLlmOutputFieldType[]).map((type) => (
              <SelectItem key={type} value={type}>{outputTypeLabels[type]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-0.5">
          <IconButton
            ariaExpanded={descriptionExpanded}
            ariaLabel={descriptionExpanded ? "收起 JSON 字段描述" : "展开 JSON 字段描述"}
            className={descriptionExpanded ? "bg-accent text-foreground" : undefined}
            icon={ExpandIcon}
            onClick={() => setDescriptionExpanded((expanded) => !expanded)}
            tooltip={descriptionExpanded ? "收起描述" : "展开描述"}
          />
          <IconButton
            ariaLabel="删除 JSON 字段"
            className="text-muted-foreground hover:text-destructive"
            disabled={fields.length <= 1}
            icon={MinusSignIcon}
            onClick={onDelete}
            tooltip="删除参数"
          />
        </div>
      </div>
      {descriptionExpanded ? (
        <Input
          aria-label={`${field.name || "JSON 字段"}描述`}
          className="h-9 text-xs"
          maxLength={LLM_OUTPUT_DESCRIPTION_MAX_LENGTH}
          onChange={(event) => onChange({ ...field, description: event.target.value })}
          placeholder="描述（可选）"
          value={field.description}
        />
      ) : null}
    </div>
  );
}

function JsonOutputFormatHint() {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span className="ml-1 inline-flex">
            <HugeiconsIcon
              aria-hidden="true"
              icon={InformationCircleIcon}
              size={12}
              strokeWidth={1.8}
            />
          </span>
        </TooltipTrigger>
        <TooltipContent side="top" sideOffset={6}>
          仅支持豆包系列模型
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function IdentifierInput({
  ariaLabel,
  maxLength,
  onChange,
  value,
}: {
  ariaLabel: string;
  maxLength: number;
  onChange: (value: string) => void;
  value: string;
}) {
  const invalid = Boolean(value) && (!LLM_IDENTIFIER_PATTERN.test(value) || value.length > maxLength);
  return (
    <Input
      aria-label={ariaLabel}
      aria-invalid={invalid}
      className={cn("h-9 text-xs", invalid && "border-destructive")}
      maxLength={maxLength}
      onChange={(event) => onChange(event.target.value)}
      placeholder="变量名"
      value={value}
    />
  );
}

function IconButton({ ariaExpanded, ariaLabel, className, disabled, icon, onClick, tooltip }: {
  ariaExpanded?: boolean;
  ariaLabel: string;
  className?: string;
  disabled?: boolean;
  icon: typeof Add01Icon;
  onClick?: () => void;
  tooltip: string;
}) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Button
            aria-expanded={ariaExpanded}
            aria-label={ariaLabel}
            className={cn("size-8 p-0", className)}
            disabled={disabled}
            onClick={onClick}
            size="sm"
            type="button"
            variant="ghost"
          >
            <HugeiconsIcon icon={icon} size={15} strokeWidth={1.8} />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="top" sideOffset={6}>{tooltip}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
