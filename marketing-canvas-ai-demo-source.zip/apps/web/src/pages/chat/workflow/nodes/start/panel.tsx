import {
  DEFAULT_WORKFLOW_MESSAGE_SENDING_WINDOW,
  WORKFLOW_ENTRY_MAX_ENTRIES,
  WORKFLOW_ENTRY_WINDOW_MAX_DAYS,
  WORKFLOW_ENTRY_WINDOW_MAX_HOURS,
  type WorkflowEntryPolicy,
  type WorkflowMessageSendingWindow,
  type WorkflowStartEntryMode,
  type WorkflowStartTrigger,
} from "@chatai/contracts";
import { Copy01Icon, HelpCircleIcon } from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { TimePicker } from "@/components/ui/time-picker";
import { Spinner } from "@/components/ui/spinner";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { NodeSettingsProps } from "../../panels/types";
import type { WorkflowDraftSaveStatus } from "../../workflow-repository-types";
import {
  getStartNodeSourceIds,
  isChatAiStartNodeData,
  type WorkflowNodeConfigPatch,
} from "../../types";
import type { WorkflowStartOption } from "./options";
import {
  FriendAddWaySelection,
  type FriendAddWaySelectionValue,
} from "./friend-add-way-selection";
import { ManagedAccountSelection } from "./managed-account-selection";
import { MessageKeywords } from "./message-keywords";
import { WecomMemberSelection } from "./wecom-member-selection";
import { getWorkflowDirectEntryEndpoint } from "./direct-entry-api";
import { getDirectEntryLabel } from "./entry-mode";
import { WecomTagSelector } from "../../../components/wecom-tag-selector";
import { useWorkflowSurface } from "../../workflow-surface";
import { createWeComMemberRootsFromOptions } from "../../workflow-wecom-member-resource";

export function StartConfig({
  allowedEntryEventTypes = [],
  node,
  onNodeChange,
  resources,
  seats,
  testContext,
  workflowId,
  workUsers = [],
}: NodeSettingsProps<"start"> & {
  seats?: WorkflowStartOption[];
  workUsers?: WorkflowStartOption[];
}) {
  const startData = node.data;
  const { entryPolicy, triggers } = startData;
  const surface = useWorkflowSurface();
  const chatAiStartData = isChatAiStartNodeData(startData) ? startData : undefined;
  const isChatAi = chatAiStartData !== undefined;
  const canUseDirectPush = !isChatAi || !surface.embedded;
  const entryMode = canUseDirectPush ? (startData.entryMode ?? "event") : "event";
  const directEntryLabel = getDirectEntryLabel(startData);
  const sourceIds = getStartNodeSourceIds(startData);
  const managedAccounts = resources?.managedAccounts;
  const wecomMembers = resources?.wecomMembers;
  const messageSendingWindow = startData.messageSendingWindow
    ?? DEFAULT_WORKFLOW_MESSAGE_SENDING_WINDOW;
  const sourceOptions = isChatAi
    ? seats ?? managedAccounts?.options ?? []
    : workUsers;
  const wecomRoots = wecomMembers?.roots ?? createWeComMemberRootsFromOptions(sourceOptions);
  const sourceLabel = isChatAi ? "托管账号" : "企微成员";
  const allowedEventTypes = new Set(allowedEntryEventTypes);
  const updateStartConfig = (patch: {
    entryMode?: WorkflowStartEntryMode;
    entryPolicy?: WorkflowEntryPolicy;
    messageSendingWindow?: WorkflowMessageSendingWindow;
    seatIds?: number[];
    triggers?: WorkflowStartTrigger[];
    workUserIds?: number[];
  }) => {
    const nextSourceIds = (isChatAi ? patch.seatIds : patch.workUserIds) ?? sourceIds;
    const nextEntryMode = patch.entryMode ?? entryMode;
    const nextTriggers = patch.triggers ?? triggers;
    const configured = nextSourceIds.length > 0
      && (nextEntryMode !== "event" || nextTriggers.length > 0);
    onNodeChange({
      ...patch,
      metric: configured
        ? `${nextSourceIds.length} 个${sourceLabel} · ${formatEntryModeMetric(nextEntryMode, nextTriggers.length, directEntryLabel)}`
        : "待配置进入方式",
      status: configured ? "ready" : "warning",
    } as WorkflowNodeConfigPatch<"start">);
  };
  return (
    <div className="-mx-1 -mt-1">
      <section>
        <h3 className="px-1 py-3 text-[15px] font-semibold text-foreground">
          {sourceLabel}
        </h3>
        <div className="pb-3">
          {isChatAi ? (
            <div className="px-1 pt-1">
              <ManagedAccountSelection
                onRetry={managedAccounts?.reload}
                onToggle={(id, checked) => updateStartConfig({
                  seatIds: toggleValue(sourceIds, id, checked),
                })}
                options={sourceOptions}
                selectedIds={sourceIds}
                status={managedAccounts?.status ?? "ready"}
              />
            </div>
          ) : (
            <div className="px-1 pt-1">
              <WecomMemberSelection
                memberLimit={wecomMembers?.memberLimit ?? 100}
                onChange={(workUserIds) => updateStartConfig({ workUserIds })}
                onRetry={wecomMembers?.reload}
                roots={wecomRoots}
                selectedIds={sourceIds}
                status={wecomMembers?.status ?? "ready"}
              />
            </div>
          )}
        </div>
      </section>

      <div className="px-1">
        <section className="pb-3">
          <h3 className="py-3 text-[15px] font-semibold text-foreground">进入方式</h3>
          <RadioGroup
            aria-label="进入方式"
            className="flex items-center gap-6"
            onValueChange={(mode) => {
              if (mode === "event" || (mode === "direct-push" && canUseDirectPush)) {
                updateStartConfig({ entryMode: mode, triggers: [] });
              }
            }}
            value={entryMode}
          >
            <label className="flex items-center gap-2 text-[13px] text-foreground">
              <RadioGroupItem value="event" />
              <span>事件触发</span>
            </label>
            <label className="flex items-center gap-2 text-[13px] text-foreground">
              <RadioGroupItem disabled={!canUseDirectPush} value="direct-push" />
              <span>{directEntryLabel}</span>
            </label>
          </RadioGroup>
        </section>

        {entryMode === "event" ? (
          <section className="pb-3">
            <div className="space-y-5 rounded-[8px] border bg-card p-3">
            <div className="space-y-2.5">
              <p className="text-[13px] font-medium text-foreground">选择事件</p>
              <Select
                onValueChange={(eventType) => updateStartConfig({
                  triggers: [createTrigger(eventType as WorkflowStartTrigger["type"])],
                })}
                value={triggers[0]?.type}
              >
                <SelectTrigger
                  aria-label="选择事件"
                  className="h-9 w-full px-3 text-[13px]"
                >
                  <SelectValue placeholder="请选择事件" />
                </SelectTrigger>
                <SelectContent>
                  {allowedEventTypes.has("contact.friend_added") ? (
                    <SelectItem value="contact.friend_added">添加好友</SelectItem>
                  ) : null}
                  {allowedEventTypes.has("contact.tag_added") ? (
                    <SelectItem value="contact.tag_added">
                      添加标签
                    </SelectItem>
                  ) : null}
                  {allowedEventTypes.has("message.received") ? (
                    <SelectItem value="message.received">用户发送消息</SelectItem>
                  ) : null}
                </SelectContent>
              </Select>
            </div>

            {hasTrigger(triggers, "contact.friend_added") ? (
              <TriggerParameter label="添加好友来源">
                <FriendAddWaySelection
                  groups={resources?.friendAddWays?.groups ?? []}
                  onChange={(next) => updateStartConfig({
                    triggers: [toFriendAddedTrigger(next)],
                  })}
                  onRetry={resources?.friendAddWays?.reload}
                  status={resources?.friendAddWays?.status ?? "ready"}
                  value={getFriendAddWayValue(triggers)}
                />
              </TriggerParameter>
            ) : null}
            {hasTrigger(triggers, "contact.tag_added") ? (
              <TriggerParameter label="选择标签">
                <WecomTagSelector
                  allowCrossGroup
                  maxSelected={5}
                  multiple
                  onChange={(tagIds) => updateStartConfig({
                    triggers: [{ tagIds, type: "contact.tag_added" }],
                  })}
                  value={getTagIds(triggers)}
                />
              </TriggerParameter>
            ) : null}
            {hasTrigger(triggers, "message.received") ? (
              <MessageKeywords
                onChange={(keywords) => updateStartConfig({
                  triggers: [{ keywords, type: "message.received" }],
                })}
                values={getMessageKeywords(triggers)}
              />
            ) : null}
            </div>
          </section>
        ) : isChatAi ? (
          <DirectEntryEndpoint
            saveState={testContext?.saveState ?? "saved"}
            workflowId={workflowId}
          />
        ) : null}
      </div>

      <section>
        <h3 className="px-1 py-3 text-[15px] font-semibold text-foreground">
          进入限制
        </h3>
        <div className="px-1 pb-3">
          <RadioGroup
            aria-label="进入限制"
            onValueChange={(mode) => updateStartConfig({ entryPolicy: createEntryPolicy(mode) })}
            value={entryPolicy.mode}
          >
            <RadioRow label="不允许重复进入" value="never" />
            <RadioRow inline label="每个客户最多进入" value="lifetime_limit">
              <EntryCountSelect
                ariaLabel="最多进入次数"
                disabled={entryPolicy.mode !== "lifetime_limit"}
                onChange={(maxEntries) => updateStartConfig({
                  entryPolicy: { maxEntries, mode: "lifetime_limit" },
                })}
                value={entryPolicy.mode === "lifetime_limit" ? entryPolicy.maxEntries : 1}
              />
            </RadioRow>
            <RadioRow label="周期进入限制" value="rolling_window">
              <RollingWindowControls
                disabled={entryPolicy.mode !== "rolling_window"}
                onChange={(nextPolicy) => updateStartConfig({ entryPolicy: nextPolicy })}
                value={entryPolicy.mode === "rolling_window"
                  ? entryPolicy
                  : createRollingWindowEntryPolicy()}
              />
            </RadioRow>
          </RadioGroup>
        </div>
      </section>

      <section>
        <div className="flex items-center gap-1.5 px-1 py-3">
          <h3 className="text-[15px] font-semibold text-foreground">消息发送时段</h3>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  aria-label="查看消息发送时段说明"
                  className="size-5 rounded-full p-0 text-muted-foreground"
                  size="icon"
                  type="button"
                  variant="ghost"
                >
                  <HugeiconsIcon icon={HelpCircleIcon} size={15} strokeWidth={1.8} />
                </Button>
              </TooltipTrigger>
              <TooltipContent className="max-w-80" side="top" sideOffset={6}>
                <ol className="list-decimal space-y-1 pl-4">
                  <li>消息和触达任务仅在每日设置的有效时段内下发，时段外不会立即执行</li>
                  <li>若节点在时段外到达，系统会延迟到下一个允许发送的时间段，降低打扰风险</li>
                </ol>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <div className="px-1 pb-3">
          <div className="flex items-center gap-2">
            <TimePicker
              aria-label="消息发送开始时间"
              className="min-w-0 flex-1"
              onValueChange={(startTime) => updateStartConfig({
                messageSendingWindow: { ...messageSendingWindow, startTime },
              })}
              value={messageSendingWindow.startTime}
            />
            <span className="shrink-0 text-[13px] text-muted-foreground">至</span>
            <TimePicker
              aria-label="消息发送结束时间"
              className="min-w-0 flex-1"
              onValueChange={(endTime) => updateStartConfig({
                messageSendingWindow: { ...messageSendingWindow, endTime },
              })}
              value={messageSendingWindow.endTime}
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function DirectEntryEndpoint({ saveState, workflowId }: {
  saveState: WorkflowDraftSaveStatus;
  workflowId?: string;
}) {
  const surface = useWorkflowSurface();
  const loadedWorkflowIdRef = useRef<string | null>(null);
  const [requestVersion, setRequestVersion] = useState(0);
  const [state, setState] = useState<
    | { kind: "error" }
    | { kind: "loading" }
    | { endpointUrl: string; kind: "ready"; workflowId: string }
  >({ kind: "loading" });

  useEffect(() => {
    if (!workflowId || saveState !== "saved" || loadedWorkflowIdRef.current === workflowId) return;
    let active = true;
    setState({ kind: "loading" });
    void getWorkflowDirectEntryEndpoint(workflowId, surface.apiBasePath).then(({ endpointKey }) => {
      if (!active) return;
      const endpointUrl = new URL("/workflow/endpoint", window.location.origin);
      endpointUrl.searchParams.set("key", endpointKey);
      loadedWorkflowIdRef.current = workflowId;
      setState({ endpointUrl: endpointUrl.toString(), kind: "ready", workflowId });
    }).catch(() => {
      if (active) setState({ kind: "error" });
    });
    return () => {
      active = false;
    };
  }, [requestVersion, saveState, surface.apiBasePath, workflowId]);

  if (!workflowId) return null;
  const endpointReady = state.kind === "ready" && state.workflowId === workflowId;
  return (
    <section className="pb-3">
      <div className="space-y-2.5 rounded-[8px] border bg-card p-3">
        <p className="text-[13px] font-medium text-foreground">推送地址</p>
        {endpointReady ? (
          <div className="flex min-w-0 items-center gap-2">
            <Input aria-label="推送地址" className="min-w-0 flex-1" readOnly value={state.endpointUrl} />
            <Button
              aria-label="复制推送地址"
              className="shrink-0"
              onClick={() => void copyDirectEntryEndpoint(state.endpointUrl)}
              size="icon"
              title="复制推送地址"
              type="button"
              variant="outline"
            >
              <HugeiconsIcon icon={Copy01Icon} size={16} strokeWidth={1.8} />
            </Button>
          </div>
        ) : saveState === "dirty" || saveState === "saving" ? (
          <div className="flex h-9 items-center gap-2 text-[13px] text-muted-foreground" role="status">
            <Spinner size={14} variant="classic" />
            <span>正在保存</span>
          </div>
        ) : saveState === "error" ? (
          <div className="flex h-9 items-center text-[13px] text-destructive">保存失败</div>
        ) : state.kind === "loading" ? (
          <div className="flex h-9 items-center gap-2 text-[13px] text-muted-foreground" role="status">
            <Spinner size={14} variant="classic" />
            <span>正在加载</span>
          </div>
        ) : state.kind === "error" ? (
          <div className="flex h-9 items-center justify-between gap-3">
            <span className="text-[13px] text-destructive">加载失败</span>
            <Button onClick={() => setRequestVersion(version => version + 1)} size="sm" type="button" variant="outline">
              重试
            </Button>
          </div>
        ) : null}
      </div>
    </section>
  );
}

async function copyDirectEntryEndpoint(endpointUrl: string) {
  try {
    await navigator.clipboard.writeText(endpointUrl);
    toast.success("已复制推送地址", { position: "top-center" });
  } catch {
    toast.error("操作失败，请稍后重试", { position: "top-center" });
  }
}

function formatEntryModeMetric(
  mode: WorkflowStartEntryMode,
  triggerCount: number,
  directEntryLabel: string,
) {
  if (mode === "direct-push") return directEntryLabel;
  return `${triggerCount} 个触发条件`;
}

function TriggerParameter({ children, label }: {
  children?: ReactNode;
  label: string;
}) {
  return (
    <div className="space-y-2.5">
      <p className="text-[13px] font-medium text-foreground">{label}</p>
      {children}
    </div>
  );
}

function RadioRow({ children, inline = false, label, value }: {
  children?: ReactNode;
  inline?: boolean;
  label: string;
  value: WorkflowEntryPolicy["mode"];
}) {
  return (
    <div className={inline ? "flex items-center gap-2" : "space-y-2"}>
      <label className="flex items-center gap-2 text-[13px] text-foreground">
        <RadioGroupItem value={value} />
        <span>{label}</span>
      </label>
      {children}
    </div>
  );
}

function EntryCountSelect({ ariaLabel, disabled = false, onChange, value }: {
  ariaLabel: string;
  disabled?: boolean;
  onChange(value: number): void;
  value: number;
}) {
  return (
    <Select
      disabled={disabled}
      onValueChange={(nextValue) => onChange(Number(nextValue))}
      value={String(value)}
    >
      <SelectTrigger
        aria-label={ariaLabel}
        className="h-9 w-[82px] shrink-0 px-3 text-[13px]"
      >
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {Array.from({ length: WORKFLOW_ENTRY_MAX_ENTRIES }, (_, index) => index + 1).map(count => (
          <SelectItem key={count} value={String(count)}>{count}次</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function RollingWindowControls({ disabled, onChange, value }: {
  disabled: boolean;
  onChange(value: Extract<WorkflowEntryPolicy, { mode: "rolling_window" }>): void;
  value: Extract<WorkflowEntryPolicy, { mode: "rolling_window" }>;
}) {
  return (
    <div className="ml-6 flex items-center gap-2 whitespace-nowrap">
      <NumberInput
        ariaLabel="时间范围"
        disabled={disabled}
        max={getRollingWindowMaximum(value.windowUnit)}
        onChange={(windowSize) => onChange({ ...value, windowSize })}
        value={value.windowSize}
      />
      <Select
        disabled={disabled}
        onValueChange={(windowUnit: "hour" | "day") => onChange({
          ...value,
          windowSize: Math.min(value.windowSize, getRollingWindowMaximum(windowUnit)),
          windowUnit,
        })}
        value={value.windowUnit}
      >
        <SelectTrigger
          aria-label="时间单位"
          className="h-9 w-[92px] shrink-0 px-3 text-[13px]"
        >
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="hour">小时</SelectItem>
          <SelectItem value="day">天</SelectItem>
        </SelectContent>
      </Select>
      <span className="text-[13px] text-foreground">内最多进入</span>
      <EntryCountSelect
        ariaLabel="时间范围内最多进入次数"
        disabled={disabled}
        onChange={(maxEntries) => onChange({ ...value, maxEntries })}
        value={value.maxEntries}
      />
    </div>
  );
}

function NumberInput({ ariaLabel, disabled = false, max, onChange, value }: {
  ariaLabel: string;
  disabled?: boolean;
  max: number;
  onChange(value: number): void;
  value: number;
}) {
  return (
    <Input
      aria-label={ariaLabel}
      className="h-9 w-[70px] shrink-0 px-2.5"
      disabled={disabled}
      max={max}
      min={1}
      onChange={(event) => {
        const nextValue = Math.trunc(Number(event.target.value)) || 1;
        onChange(Math.min(max, Math.max(1, nextValue)));
      }}
      step={1}
      type="number"
      value={value}
    />
  );
}

function createEntryPolicy(mode: string): WorkflowEntryPolicy {
  if (mode === "never") return { mode: "never" };
  if (mode === "rolling_window") return createRollingWindowEntryPolicy();
  return { maxEntries: 1, mode: "lifetime_limit" };
}

function createRollingWindowEntryPolicy(): Extract<WorkflowEntryPolicy, { mode: "rolling_window" }> {
  return { maxEntries: 1, mode: "rolling_window", windowSize: 7, windowUnit: "day" };
}

function getRollingWindowMaximum(unit: "hour" | "day") {
  return unit === "hour" ? WORKFLOW_ENTRY_WINDOW_MAX_HOURS : WORKFLOW_ENTRY_WINDOW_MAX_DAYS;
}

function toggleValue(values: number[], value: number, checked: boolean) {
  return checked ? [...new Set([...values, value])] : values.filter(item => item !== value);
}

function hasTrigger(triggers: WorkflowStartTrigger[], type: WorkflowStartTrigger["type"]) {
  return triggers.some(trigger => trigger.type === type);
}

function createTrigger(type: WorkflowStartTrigger["type"]): WorkflowStartTrigger {
  if (type === "contact.friend_added") return { sourceIds: [], type };
  if (type === "contact.tag_added") return { tagIds: [], type };
  return { keywords: [], type };
}

function getFriendAddWayValue(triggers: WorkflowStartTrigger[]): FriendAddWaySelectionValue {
  const trigger = triggers.find(item => item.type === "contact.friend_added");
  if (!trigger || trigger.type !== "contact.friend_added") {
    return { addWayKey: null, sourceIds: [], sourceMatchMode: "all" };
  }

  return {
    addWayKey: trigger.addWayKey ?? null,
    sourceIds: trigger.sourceIds,
    sourceMatchMode: trigger.sourceMatchMode ?? "all",
  };
}

function toFriendAddedTrigger(value: FriendAddWaySelectionValue): WorkflowStartTrigger {
  return {
    type: "contact.friend_added",
    sourceIds: value.sourceIds,
    ...(value.addWayKey ? { addWayKey: value.addWayKey } : {}),
    ...(value.addWayKey && value.sourceMatchMode === "any"
      ? { sourceMatchMode: "any" }
      : {}),
  };
}

function getTagIds(triggers: WorkflowStartTrigger[]) {
  return triggers.find(trigger => trigger.type === "contact.tag_added")?.tagIds ?? [];
}

function getMessageKeywords(triggers: WorkflowStartTrigger[]) {
  return triggers.find(trigger => trigger.type === "message.received")?.keywords ?? [];
}
