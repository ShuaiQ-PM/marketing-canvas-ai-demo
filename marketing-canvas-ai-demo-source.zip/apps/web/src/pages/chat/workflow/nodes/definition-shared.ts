import { getWorkflowNodeContract } from "@chatai/contracts";
import {
  WORKFLOW_COMPACT_NODE_ESTIMATED_HEIGHT,
  WORKFLOW_NODE_ESTIMATED_HEIGHT,
  WORKFLOW_NODE_WIDTH,
  WORKFLOW_TERMINAL_NODE_ESTIMATED_HEIGHT,
} from "../constants";
import type {
  BranchNodeData,
  WorkflowNodeData,
  WorkflowNodeDataMap,
  WorkflowNodeKind,
  WorkflowNodeStatus,
  WorkflowNodeValidationIssue,
} from "../types";
import {
  getBranchPathTop,
  getWorkflowBranchPaths,
} from "../branch-paths";
import type {
  WorkflowSourceHandleDefinition,
  WorkflowTargetHandleDefinition,
} from "../node-handle-definitions";
import type { WorkflowNodeLayoutMetrics } from "./definition-types";

type NodeDataInput<TKind extends WorkflowNodeKind> = Omit<
  WorkflowNodeDataMap[TKind],
  "kind" | "schemaVersion" | "status"
> & {
  status?: WorkflowNodeStatus;
};

export const sourceNodeKinds: WorkflowNodeKind[] = [
  "start",
  "wait",
  "wait-event",
  "branch",
  "audience-filter",
  "ratio-split",
  "message",
  "marketing-message",
  "message-query",
  "tag",
  "coupon",
  "handoff",
  "agent",
  "llm",
  "order-bind",
  "order-query",
  "order-conversion",
  "tag-query",
  "customer-update",
  "ai-collect",
  "ai-intent",
  "smartsheet-write",
  "ticket-create",
];
export const targetNodeKinds: WorkflowNodeKind[] = [
  "wait",
  "wait-event",
  "branch",
  "audience-filter",
  "ratio-split",
  "message",
  "marketing-message",
  "message-query",
  "tag",
  "coupon",
  "handoff",
  "agent",
  "llm",
  "order-bind",
  "order-query",
  "order-conversion",
  "tag-query",
  "customer-update",
  "ai-collect",
  "ai-intent",
  "smartsheet-write",
  "ticket-create",
  "end",
];

export const standardNodeLayout: WorkflowNodeLayoutMetrics = {
  estimatedHeight: WORKFLOW_NODE_ESTIMATED_HEIGHT,
  width: WORKFLOW_NODE_WIDTH,
};

export const compactNodeLayout: WorkflowNodeLayoutMetrics = {
  estimatedHeight: WORKFLOW_COMPACT_NODE_ESTIMATED_HEIGHT,
  width: WORKFLOW_NODE_WIDTH,
};

export const terminalNodeLayout: WorkflowNodeLayoutMetrics = {
  estimatedHeight: WORKFLOW_TERMINAL_NODE_ESTIMATED_HEIGHT,
  width: WORKFLOW_NODE_WIDTH,
};

export function createNodeData<TKind extends WorkflowNodeKind>(
  kind: TKind,
  data: NodeDataInput<TKind>,
): WorkflowNodeData<TKind> {
  return {
    ...data,
    kind,
    schemaVersion: getWorkflowNodeContract(kind).currentDraftSchemaVersion,
    status: data.status ?? "ready",
  } as WorkflowNodeData<TKind>;
}

export function pickDefinedWorkflowConfig(config: Record<string, unknown>) {
  return Object.fromEntries(
    Object.entries(config).filter(([, value]) => value !== undefined),
  );
}

export function hasText(value: unknown) {
  return typeof value === "string" && value.trim().length > 0;
}

export function createCatalogIssue(
  code: string,
  message: string,
): WorkflowNodeValidationIssue {
  return {
    code,
    message,
    severity: "warning",
    source: "catalog",
  };
}

export function createDefaultSourceHandles(): WorkflowSourceHandleDefinition[] {
  return [{ isDefault: true, outletKind: "default", top: 16 }];
}

export function createNoSourceHandles(): WorkflowSourceHandleDefinition[] {
  return [];
}

export function createBranchSourceHandles(
  data: BranchNodeData,
): WorkflowSourceHandleDefinition[] {
  return getWorkflowBranchPaths(data).map((branch) => ({
    id: branch.id,
    ...(branch.isDefault ? { isDefault: true } : {}),
    label: branch.label,
    outletKind: "branch-path",
    top: getBranchPathTop(data, branch.id),
  }));
}

export function createDefaultTargetHandles(): WorkflowTargetHandleDefinition[] {
  return [{ maxConnections: Number.POSITIVE_INFINITY }];
}

export function createNoTargetHandles(): WorkflowTargetHandleDefinition[] {
  return [];
}
