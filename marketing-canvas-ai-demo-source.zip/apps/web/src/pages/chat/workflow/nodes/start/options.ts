export type WorkflowStartOption = {
  avatarUrl?: string;
  id: number;
  label: string;
};
