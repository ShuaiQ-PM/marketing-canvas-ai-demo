import { useEffect, useState } from "react";
import {
  WORKFLOW_RATIO_SPLIT_GROUP_MAX,
  WORKFLOW_RATIO_SPLIT_GROUP_LABEL_MAX_LENGTH,
  WORKFLOW_RATIO_SPLIT_GROUP_MIN,
  WORKFLOW_RATIO_SPLIT_TOTAL_BASIS_POINTS,
  getWorkflowRatioSplitBasisPointsTotal,
  type WorkflowRatioSplitDraftGroup,
} from "@chatai/contracts";
import { Add01Icon, Delete01Icon } from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { LimitedInput } from "@/components/ui/limited-input";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@/components/ui/input-group";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { WorkflowSettingsSection } from "../../panels/settings-section";
import type { NodeSettingsProps } from "../../panels/types";
import {
  addWorkflowRatioSplitGroup,
  formatBasisPoints,
  getWorkflowRatioSplitGroups,
  removeWorkflowRatioSplitGroup,
} from "./groups";

export function RatioSplitConfig({ edges, node, onNodeChange }: NodeSettingsProps<"ratio-split">) {
  const [pendingDeleteGroup, setPendingDeleteGroup] = useState<WorkflowRatioSplitDraftGroup | null>(null);
  const groups = getWorkflowRatioSplitGroups(node.data);
  const totalBasisPoints = getWorkflowRatioSplitBasisPointsTotal(groups);

  const updateGroups = (nextGroups: WorkflowRatioSplitDraftGroup[]) => {
    onNodeChange({ groups: nextGroups });
  };
  const updateGroup = (groupId: string, patch: Partial<WorkflowRatioSplitDraftGroup>) => {
    updateGroups(groups.map(group => group.id === groupId ? { ...group, ...patch, id: group.id } : group));
  };
  const deleteGroup = (group: WorkflowRatioSplitDraftGroup) => {
    updateGroups(removeWorkflowRatioSplitGroup(groups, group.id));
    setPendingDeleteGroup(null);
  };
  const requestDeleteGroup = (group: WorkflowRatioSplitDraftGroup) => {
    const connected = edges.some(edge => edge.source === node.id && edge.sourceHandle === group.id);
    if (connected) {
      setPendingDeleteGroup(group);
      return;
    }
    deleteGroup(group);
  };

  return (
    <WorkflowSettingsSection
      actions={(
        <span className="text-xs text-muted-foreground">
          比例合计 {formatBasisPoints(totalBasisPoints)}
        </span>
      )}
      title="分流设置"
    >
      <div className="space-y-3">
        {groups.map((group, index) => {
          const labelLength = group.label.length;
          const labelTooLong = labelLength > WORKFLOW_RATIO_SPLIT_GROUP_LABEL_MAX_LENGTH;

          return (
          <section
            className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-x-2 gap-y-2 rounded-[8px] border p-3"
            key={group.id}
          >
            <Label htmlFor={`ratio-split-label-${node.id}-${group.id}`}>
              分组 {String.fromCharCode(65 + index)}
            </Label>
            <div className="relative min-w-0">
              <LimitedInput
                aria-invalid={labelTooLong || undefined}
                className={cn(
                  "pr-12",
                  labelTooLong && "border-destructive focus-visible:border-destructive focus-visible:ring-destructive/15",
                )}
                id={`ratio-split-label-${node.id}-${group.id}`}
                maxLength={WORKFLOW_RATIO_SPLIT_GROUP_LABEL_MAX_LENGTH}
                onValueChange={label => updateGroup(group.id, { label })}
                value={group.label}
              />
              <span
                className={cn(
                  "pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-[11px] tabular-nums text-muted-foreground",
                  labelTooLong && "text-destructive",
                )}
              >
                {labelLength}/{WORKFLOW_RATIO_SPLIT_GROUP_LABEL_MAX_LENGTH}
              </span>
            </div>
            <Button
              aria-label={`删除${group.label || `分组 ${String.fromCharCode(65 + index)}`}`}
              className="size-7 p-0 text-destructive hover:text-destructive"
              disabled={groups.length <= WORKFLOW_RATIO_SPLIT_GROUP_MIN}
              onClick={() => requestDeleteGroup(group)}
              size="sm"
              type="button"
              variant="ghost"
            >
              <HugeiconsIcon icon={Delete01Icon} size={14} strokeWidth={1.8} />
            </Button>
            <Label htmlFor={`ratio-split-percentage-${node.id}-${group.id}`}>分流比例</Label>
            <PercentageInput
              basisPoints={group.basisPoints}
              id={`ratio-split-percentage-${node.id}-${group.id}`}
              onChange={basisPoints => updateGroup(group.id, { basisPoints })}
            />
          </section>
          );
        })}

        <Button
          className="h-9 w-full rounded-[8px]"
          disabled={groups.length >= WORKFLOW_RATIO_SPLIT_GROUP_MAX}
          onClick={() => updateGroups(addWorkflowRatioSplitGroup(groups))}
          type="button"
          variant="outline"
        >
          <HugeiconsIcon icon={Add01Icon} size={15} strokeWidth={1.8} />
          添加分组
        </Button>
      </div>

      <AlertDialog
        onOpenChange={(open) => {
          if (!open) setPendingDeleteGroup(null);
        }}
        open={Boolean(pendingDeleteGroup)}
      >
        <AlertDialogContent size="sm">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除分组</AlertDialogTitle>
            <AlertDialogDescription>删除后，该分组对应的下游连线也会被删除</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>取消</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (pendingDeleteGroup) deleteGroup(pendingDeleteGroup);
              }}
              variant="destructive"
            >
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </WorkflowSettingsSection>
  );
}

function PercentageInput({
  basisPoints,
  id,
  onChange,
}: {
  basisPoints: number;
  id: string;
  onChange: (basisPoints: number) => void;
}) {
  const [draft, setDraft] = useState(formatPercentageInput(basisPoints));

  useEffect(() => {
    setDraft(formatPercentageInput(basisPoints));
  }, [basisPoints]);

  return (
    <InputGroup>
      <InputGroupInput
        id={id}
        inputMode="decimal"
        onBlur={() => {
          const parsed = Number(draft);
          const normalized = Number.isFinite(parsed) ? Math.min(100, Math.max(0, parsed)) : 0;
          const nextBasisPoints = Math.round(normalized * 100);
          setDraft(formatPercentageInput(nextBasisPoints));
          if (nextBasisPoints !== basisPoints) onChange(nextBasisPoints);
        }}
        onChange={(event) => {
          const value = event.target.value;
          if (!/^\d{0,3}(?:\.\d{0,2})?$/.test(value)) return;
          setDraft(value);
          const nextBasisPoints = parsePercentageBasisPoints(value);
          if (nextBasisPoints !== null) onChange(nextBasisPoints);
        }}
        value={draft}
      />
      <InputGroupAddon align="inline-end" className="pr-3">%</InputGroupAddon>
    </InputGroup>
  );
}

function parsePercentageBasisPoints(value: string) {
  if (!value) return null;
  const percentage = Number(value);
  if (!Number.isFinite(percentage) || percentage < 0 || percentage > 100) return null;
  const basisPoints = Math.round(percentage * 100);
  return basisPoints <= WORKFLOW_RATIO_SPLIT_TOTAL_BASIS_POINTS ? basisPoints : null;
}

function formatPercentageInput(basisPoints: number) {
  return String(Number((basisPoints / 100).toFixed(2)));
}
