import { ListTodoIcon } from "@hugeicons/core-free-icons";
import type { WorkflowNodeDefinition } from "../definition-types";
import { createStandardNodeDefinition } from "../standard-node-definition-factory";
import {
  getVariableContentPreview,
  normalizeVariableContent,
} from "../variable-content/content";

const baseDefinition = createStandardNodeDefinition({
  accentClassName: "bg-emerald-600 text-white",
  accentRgb: "5 150 105",
  description: "创建工单，确保关键客户动作（如问题处理、回访、活动跟进等）不被遗漏",
  icon: ListTodoIcon,
  kind: "ticket-create",
  label: "创建工单",
  metric: "待配置标题",
  paletteGroup: "operate",
  sort: 125,
});

export const ticketCreateNodeDefinition: WorkflowNodeDefinition<"ticket-create"> = {
  ...baseDefinition,
  createDefaultData: () => ({
    ...baseDefinition.createDefaultData(),
    description: [],
    metric: "待配置标题",
    priority: "medium",
    status: "warning",
    ticketTitle: [],
  }),
  sanitizeData: data => ({
    ...data,
    description: normalizeVariableContent(data.description),
    priority: data.priority === "low" || data.priority === "high" || data.priority === "medium"
      ? data.priority
      : "medium",
    ticketTitle: normalizeVariableContent(data.ticketTitle),
  }),
  validate: node => getVariableContentPreview(node.data.ticketTitle)
    ? []
    : [{
        code: "ticket-create-title-required",
        message: "需配置工单标题",
        severity: "warning",
        source: "config",
      }],
};
