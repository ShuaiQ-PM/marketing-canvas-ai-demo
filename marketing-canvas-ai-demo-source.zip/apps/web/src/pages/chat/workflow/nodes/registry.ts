import type { WorkflowNodeKind } from "../types";
import type { WorkflowNodeDefinition } from "./definition-types";
import { agentNodeDefinition } from "./agent/definition";
import { aiCollectNodeDefinition } from "./ai-collect/definition";
import { aiIntentNodeDefinition } from "./ai-intent/definition";
import { audienceFilterNodeDefinition } from "./audience-filter/definition";
import { branchNodeDefinition } from "./branch/definition";
import { couponNodeDefinition } from "./coupon/definition";
import { customerUpdateNodeDefinition } from "./customer-update/definition";
import { endNodeDefinition } from "./end/definition";
import { handoffNodeDefinition } from "./handoff/definition";
import { llmNodeDefinition } from "./llm/definition";
import { messageNodeDefinition } from "./message/definition";
import { marketingMessageNodeDefinition } from "./marketing-message/definition";
import { messageQueryNodeDefinition } from "./message-query/definition";
import { orderBindNodeDefinition } from "./order-bind/definition";
import { orderQueryNodeDefinition } from "./order-query/definition";
import { orderConversionNodeDefinition } from "./order-conversion/definition";
import { ratioSplitNodeDefinition } from "./ratio-split/definition";
import { smartsheetWriteDefinition } from "./smartsheet-write/definition";
import { startNodeDefinition } from "./start/definition";
import { tagNodeDefinition } from "./tag/definition";
import { tagQueryNodeDefinition } from "./tag-query/definition";
import { ticketCreateNodeDefinition } from "./ticket-create/definition";
import { waitNodeDefinition } from "./wait/definition";
import { waitEventNodeDefinition } from "./wait-event/definition";

export const workflowNodeDefinitions = {
  agent: agentNodeDefinition,
  "ai-collect": aiCollectNodeDefinition,
  "ai-intent": aiIntentNodeDefinition,
  "audience-filter": audienceFilterNodeDefinition,
  branch: branchNodeDefinition,
  coupon: couponNodeDefinition,
  "customer-update": customerUpdateNodeDefinition,
  end: endNodeDefinition,
  handoff: handoffNodeDefinition,
  llm: llmNodeDefinition,
  message: messageNodeDefinition,
  "marketing-message": marketingMessageNodeDefinition,
  "message-query": messageQueryNodeDefinition,
  "order-bind": orderBindNodeDefinition,
  "order-query": orderQueryNodeDefinition,
  "order-conversion": orderConversionNodeDefinition,
  "ratio-split": ratioSplitNodeDefinition,
  "smartsheet-write": smartsheetWriteDefinition,
  start: startNodeDefinition,
  tag: tagNodeDefinition,
  "tag-query": tagQueryNodeDefinition,
  "ticket-create": ticketCreateNodeDefinition,
  wait: waitNodeDefinition,
  "wait-event": waitEventNodeDefinition,
} satisfies {
  [TKind in WorkflowNodeKind]: WorkflowNodeDefinition<TKind>;
};

export const orderedWorkflowNodeDefinitions = Object.values(workflowNodeDefinitions).sort(
  (first, second) => first.sort - second.sort,
);
