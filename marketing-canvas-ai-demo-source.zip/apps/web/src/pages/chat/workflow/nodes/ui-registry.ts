import type { WorkflowNodeKind } from "../types";
import { agentNodeUi } from "./agent/ui";
import { aiCollectNodeUi } from "./ai-collect/ui";
import { aiIntentNodeUi } from "./ai-intent/ui";
import { audienceFilterNodeUi } from "./audience-filter/ui";
import { branchNodeUi } from "./branch/ui";
import { couponNodeUi } from "./coupon/ui";
import { customerUpdateNodeUi } from "./customer-update/ui";
import { endNodeUi } from "./end/ui";
import { handoffNodeUi } from "./handoff/ui";
import { llmNodeUi } from "./llm/ui";
import { messageNodeUi } from "./message/ui";
import { marketingMessageNodeUi } from "./marketing-message/ui";
import { messageQueryNodeUi } from "./message-query/ui";
import { orderBindNodeUi } from "./order-bind/ui";
import { orderQueryNodeUi } from "./order-query/ui";
import { orderConversionNodeUi } from "./order-conversion/ui";
import { ratioSplitNodeUi } from "./ratio-split/ui";
import { smartsheetWriteUi } from "./smartsheet-write/ui";
import { startNodeUi } from "./start/ui";
import { tagNodeUi } from "./tag/ui";
import { tagQueryNodeUi } from "./tag-query/ui";
import { ticketCreateNodeUi } from "./ticket-create/ui";
import { waitNodeUi } from "./wait/ui";
import { waitEventNodeUi } from "./wait-event/ui";
import type { WorkflowNodeUiBinding } from "./ui-types";

export const workflowNodeUiRegistry = {
  agent: agentNodeUi,
  "ai-collect": aiCollectNodeUi,
  "ai-intent": aiIntentNodeUi,
  "audience-filter": audienceFilterNodeUi,
  branch: branchNodeUi,
  coupon: couponNodeUi,
  "customer-update": customerUpdateNodeUi,
  end: endNodeUi,
  handoff: handoffNodeUi,
  llm: llmNodeUi,
  message: messageNodeUi,
  "marketing-message": marketingMessageNodeUi,
  "message-query": messageQueryNodeUi,
  "order-bind": orderBindNodeUi,
  "order-query": orderQueryNodeUi,
  "order-conversion": orderConversionNodeUi,
  "ratio-split": ratioSplitNodeUi,
  "smartsheet-write": smartsheetWriteUi,
  start: startNodeUi,
  tag: tagNodeUi,
  "tag-query": tagQueryNodeUi,
  "ticket-create": ticketCreateNodeUi,
  wait: waitNodeUi,
  "wait-event": waitEventNodeUi,
} satisfies {
  [TKind in WorkflowNodeKind]: WorkflowNodeUiBinding<TKind>;
};
