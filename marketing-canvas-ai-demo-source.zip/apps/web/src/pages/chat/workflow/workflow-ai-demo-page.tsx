import { useMemo, useState } from "react";
import "./workflow-page.css";
import { ArrowLeft01Icon, MagicWand01Icon, Search01Icon } from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Spinner } from "@/components/ui/spinner";
import { Textarea } from "@/components/ui/textarea";
import { WorkflowGraphPreview } from "./workflow-graph-preview";
import { getWorkflowNodeCatalogEntry } from "./node-catalog";
import { createStartNodeData } from "./nodes/start/definition";
import type { WorkflowDraft, WorkflowNode } from "./types";

const prompts = [
  { title: "目标人群", question: "想触达哪类客户？", options: ["近 30 天新增客户", "已加好友未成交", "全部客户"] },
  { title: "营销目标", question: "这次希望达成什么目标？", options: ["促进首单转化", "提升复购", "活动到期提醒"] },
  { title: "触达方式", question: "希望用什么方式触达？", options: ["发送营销内容", "先打标签再触达", "AI 个性化跟进"] },
  { title: "分支条件", question: "触达后要根据什么条件分流？", options: ["已下单：结束；未下单：继续提醒", "已下单：打标签；未下单：人工跟进"] },
];

function makeDraft(kinds: string[]): WorkflowDraft {
  const nodeKinds = ["start", ...kinds, "end"] as const;
  const nodes = nodeKinds.map((kind, index) => {
    const id = `demo-${kind}-${index}`;
    const definition = getWorkflowNodeCatalogEntry(kind as never);
    const data = kind === "start"
      ? { ...createStartNodeData("wecom_sop"), workUserIds: [1], metric: "营销画布启动", status: "ready" as const }
      : definition.createDefaultData();
    const configured = kind === "marketing-message"
      ? { ...data, title: "发送营销内容", label: "发送营销内容", metric: "新客首单优惠", status: "ready" as const, plan: { planId: 1, planName: "新客首单优惠" }, wait: { mode: "fixed", duration: 3, unit: "hour" } }
      : kind === "wait"
        ? { ...data, title: "等待转化", label: "等待转化", metric: "等待 3 天", status: "ready" as const, duration: 3, unit: "day" }
        : data;
    return { id, type: "workflow", position: { x: index * 390, y: 0 }, data: configured } as WorkflowNode;
  });
  const edges = nodes.slice(0, -1).map((node, index) => ({
    id: `demo-edge-${index}`,
    source: node.id,
    target: nodes[index + 1]!.id,
    type: "workflow",
    data: {},
  })) as WorkflowDraft["edges"];
  return { nodes, edges, viewport: { x: 80, y: 420, zoom: 0.8 } };
}

export function WorkflowAiDemoPage() {
  const [view, setView] = useState<"list" | "editor">("list");
  const [chatOpen, setChatOpen] = useState(false);
  const [step, setStep] = useState(0);
  const [choice, setChoice] = useState("");
  const [answers, setAnswers] = useState<string[]>([]);
  const [createdCount, setCreatedCount] = useState(0);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showCanvasStatus, setShowCanvasStatus] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<string[]>([]);
  const nodeKinds = useMemo(() => ["audience-filter", "marketing-message", "wait", "branch"].slice(0, createdCount), [createdCount]);
  const draft = useMemo(() => makeDraft(nodeKinds), [nodeKinds]);

  const begin = (reset = true) => {
    if (reset) { setStep(0); setChoice(""); setAnswers([]); setMessages([]); setCreatedCount(0); setIsGenerating(false); setShowCanvasStatus(false); }
    setChatOpen(true);
  };
  const beginCanvasCreation = () => {
    setStep(0);
    setChoice("");
    setAnswers([]);
    setMessages([]);
    setCreatedCount(0);
    setIsGenerating(false);
    setShowCanvasStatus(false);
    setView("editor");
    setChatOpen(true);
  };
  const confirm = () => {
    if (!choice) return;
    setAnswers((items) => [...items, choice]);
    setChoice("");
    if (step === prompts.length - 1) {
      setStep(prompts.length);
      createCanvas();
    } else {
      setStep((value) => value + 1);
    }
  };
  const createCanvas = () => {
    setView("editor");
    setCreatedCount(0);
    setIsGenerating(true);
    setShowCanvasStatus(true);
    setChatOpen(true);
    window.setTimeout(() => setCreatedCount(1), 1_300);
    window.setTimeout(() => setCreatedCount(2), 2_650);
    window.setTimeout(() => setCreatedCount(3), 4_000);
    window.setTimeout(() => setCreatedCount(4), 5_350);
    window.setTimeout(() => setIsGenerating(false), 5_900);
    window.setTimeout(() => setShowCanvasStatus(false), 7_500);
  };
  const send = () => {
    const value = input.trim();
    if (!value) return;
    setMessages((items) => [...items, value]);
    setInput("");
  };

  return view === "list" ? (
    <div className="min-h-screen bg-muted/30">
      <div className="mx-auto max-w-[1440px] p-6">
        <div className="mb-6 flex items-center justify-between"><div><h1 className="text-xl font-semibold">营销画布</h1><p className="mt-1 text-sm text-muted-foreground">面向目标人群灵活编排营销策略，构建个性化运营链路</p></div><div className="flex items-center gap-2">
          <Button className="h-10" variant="outline" onClick={() => { setView("editor"); setChatOpen(false); }}><span>＋ 新建画布</span></Button>
          <Button className="h-10" onClick={beginCanvasCreation}><HugeiconsIcon icon={MagicWand01Icon} size={16} />智能创建</Button>
        </div></div>
        <div className="mb-4 mt-6 flex items-center justify-between">
          <div className="flex gap-6 text-sm"><span className="border-b-2 border-primary pb-2 font-medium text-primary">全部画布</span><span className="text-muted-foreground">运行中</span><span className="text-muted-foreground">草稿</span><span className="text-muted-foreground">已停止</span></div>
          <div className="relative w-64"><HugeiconsIcon className="absolute left-3 top-2.5 text-muted-foreground" icon={Search01Icon} size={16} /><Input className="pl-9" placeholder="搜索画布名称" /></div>
        </div>
        <div className="overflow-hidden rounded-lg border bg-card">
          <div className="grid grid-cols-[2fr_1fr_1fr_1fr_90px] bg-muted/40 px-5 py-3 text-xs text-muted-foreground"><span>画布名称</span><span>状态</span><span>触达人数</span><span>最近更新</span><span>操作</span></div>
          {[["新客首单转化", "新客培育 · 3 个节点", "运行中", "1,284 人", "今天 10:24"], ["沉睡客户唤醒", "客户召回 · 5 个节点", "运行中", "326 人", "昨天 16:08"], ["双十一活动提醒", "活动营销 · 4 个节点", "草稿", "—", "11月06日"]].map((row) => <div key={row[0]} className="grid grid-cols-[2fr_1fr_1fr_1fr_90px] items-center border-t px-5 py-4 text-sm"><div><div className="font-medium">{row[0]}</div><div className="mt-1 text-xs text-muted-foreground">{row[1]}</div></div><span>{row[2]}</span><span>{row[3]}</span><span>{row[4]}</span><button className="text-left text-primary" onClick={() => { setView("editor"); setChatOpen(false); }}>编辑</button></div>)}
        </div>
      </div>
      <ChatDrawer open={chatOpen} close={() => setChatOpen(false)} step={step} choice={choice} setChoice={setChoice} confirm={confirm} answers={answers} create={createCanvas} input={input} setInput={setInput} send={send} messages={messages} />
    </div>
  ) : (
    <div className="flex h-svh flex-col bg-background">
      <header className="flex h-14 shrink-0 items-center justify-between border-b bg-background px-4">
        <div className="flex items-center gap-3"><Button aria-label="返回列表" size="icon" variant="ghost" onClick={() => { setView("list"); setChatOpen(false); }}><HugeiconsIcon icon={ArrowLeft01Icon} size={18} /></Button><span className="text-sm font-semibold">新客首单转化</span><span className="rounded bg-muted px-2 py-1 text-xs text-muted-foreground">草稿</span></div>
        <div className="flex gap-2"><Button variant="outline">保存</Button><Button>发布</Button></div>
      </header>
      <main className="workflow-page relative min-h-0 flex-1 bg-[var(--workflow-canvas-bg)]">
        <WorkflowGraphPreview className="h-full w-full rounded-none border-0" draft={draft} onOpenAiChat={() => begin(false)} />
        {showCanvasStatus && <div aria-live="polite" className="absolute left-1/2 top-5 z-20 flex min-w-[270px] -translate-x-1/2 items-center gap-3 rounded-xl border bg-background/95 px-4 py-3 shadow-lg backdrop-blur-sm">
          {isGenerating ? <Spinner className="text-primary" size={18} /> : <span className="grid size-[18px] place-items-center rounded-full bg-emerald-100 text-xs font-semibold text-emerald-700">✓</span>}
          <div className="min-w-0 flex-1"><div className="text-sm font-medium">{isGenerating ? "AI 正在搭建画布" : "画布已创建"}</div><div className="mt-0.5 text-xs text-muted-foreground">{isGenerating ? `已生成 ${createdCount}/4 个节点` : "可以继续编辑节点配置"}</div></div>
          <div className="h-1.5 w-14 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${isGenerating ? Math.max(8, createdCount * 25) : 100}%` }} /></div>
        </div>}
      </main>
      <ChatDrawer open={chatOpen} close={() => setChatOpen(false)} step={step} choice={choice} setChoice={setChoice} confirm={confirm} answers={answers} create={createCanvas} input={input} setInput={setInput} send={send} messages={messages} />
    </div>
  );
}

function ChatDrawer({ open, close, step, choice, setChoice, confirm, answers, create, input, setInput, send, messages }: {
  open: boolean; close: () => void; step: number; choice: string; setChoice: (value: string) => void; confirm: () => void; answers: string[]; create: () => void; input: string; setInput: (value: string) => void; send: () => void; messages: string[];
}) {
  return <aside className={`fixed inset-y-0 left-0 z-50 flex w-[410px] max-w-[95vw] flex-col border-r bg-background shadow-2xl transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"}`} aria-hidden={!open}>
    <header className="flex h-14 items-center justify-between border-b px-4"><span className="flex items-center gap-2 text-sm font-semibold"><span className="grid size-8 place-items-center rounded-lg bg-primary/10 text-primary">✦</span>智能创建营销画布</span><Button size="icon" variant="ghost" onClick={close}>×</Button></header>
    <div className="flex-1 space-y-3 overflow-y-auto bg-muted/20 p-4">
      <div className="max-w-[95%] rounded-lg border bg-card p-3 text-sm leading-6">你好，我可以帮你把营销想法整理成一张可编辑的营销画布。先说说你想做什么，也可以点选几个选项快速确认。</div>
      {step > 0 && answers.map((answer, index) => <div key={`${answer}-${index}`} className="ml-auto w-fit rounded-lg bg-primary/10 px-3 py-2 text-sm">{prompts[index]?.title}：{answer}</div>)}
      {messages.map((message, index) => <div key={index} className="ml-auto w-fit max-w-[85%] rounded-lg bg-primary/10 px-3 py-2 text-sm">{message}</div>)}
      {messages.length > 0 && <div className="max-w-[95%] rounded-lg border bg-card p-3 text-sm">收到，我会把这条补充信息纳入方案。你可以继续使用上方卡片调整需求。</div>}
    </div>
    <div className="space-y-3 border-t bg-background p-4">
      {step < prompts.length ? <div className="rounded-xl border bg-card p-3 shadow-sm">
        <div className="mb-2 flex items-center justify-between gap-3"><span className="text-sm font-semibold">{prompts[step]?.question}</span><span className="shrink-0 text-xs text-muted-foreground">{step + 1}/{prompts.length}</span></div>
        {step === 3 && <p className="mb-2 text-xs leading-5 text-muted-foreground">我会添加条件分支，请确认两条后续路径</p>}
        <div className="grid gap-1.5">{prompts[step]?.options.map((option) => <button key={option} className={`flex min-h-9 items-center justify-between gap-3 rounded-lg border px-3 py-2 text-left text-xs leading-5 transition-colors ${choice === option ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted"}`} onClick={() => setChoice(option)}><span>{option}</span><span className="shrink-0">{choice === option ? "✓" : "›"}</span></button>)}</div>
        <div className="mt-2.5 flex justify-end"><Button size="sm" disabled={!choice} onClick={confirm}>{step === prompts.length - 1 ? "确认并创建" : "确认选择"}</Button></div>
      </div> : null}
      <div className="relative">
        <Textarea
          className="min-h-[100px] resize-none rounded-xl pb-11 pr-14 pt-3 text-sm leading-6 shadow-sm placeholder:text-muted-foreground/80"
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); send(); } }}
          placeholder="描述你的营销目标，或补充需求…"
          rows={3}
          value={input}
        />
        <Button aria-label="发送" className="absolute bottom-2 right-2 size-8 rounded-lg" disabled={!input.trim()} onClick={send} size="icon">↑</Button>
      </div>
      <div className="text-center text-[10px] text-muted-foreground">AI 生成内容仅供参考，创建后可继续编辑</div>
    </div>
  </aside>;
}
