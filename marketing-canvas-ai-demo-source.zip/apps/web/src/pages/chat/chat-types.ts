import type {
  WorkbenchGroupMemberType,
  WorkbenchMessageContentType,
} from "@chatai/contracts";

export type ChatMode = "single" | "group";

export type MessageRole = "customer" | "agent" | "system";

export type MessageStatus =
  | "pending"
  | "sending"
  | "accepted"
  | "initializing"
  | "sent"
  | "failed";

export type FileUploadQueueItem = {
  fileName: string;
  id: string;
  progress: number;
  status: "uploading" | "sending";
};

export type EmployeeProfile = {
  id: string;
  displayName: string;
};

export type GroupMember = {
  id: string;
  displayName: string;
  avatarUrl?: string;
  isOpeningAccount?: boolean;
  isReceptionAccount?: boolean;
  type: WorkbenchGroupMemberType;
};

export type CustomerChatStartInput = {
  conversationId?: string;
  seatId: string;
  thirdExternalUserId: string;
  customerName: string;
  customerAvatar: string;
  realName: string;
};

export type Account = {
  seatAIHostingEnabled?: boolean;
  seatAIHostingAuth?: boolean;
  fullAutoSwitch?: boolean;
  semiAutoAuth?: boolean;
  semiAutoSwitch?: boolean;
  id: string;
  /** 席位第三方成员 ID，对应 `xy_wap_embed_user_seat.third_userid` */
  thirdUserId?: string;
  name: string;
  avatarUrl: string;
  operator: string;
  description: string;
  phone: string;
  metrics: {
    totalCustomers: number;
    activeCustomers: number;
    agents: number;
    stores: number;
  };
  tone: string;
  unreadCount?: number;
  singleUnreadCount?: number;
  groupUnreadCount?: number;
  lastMessageTime?: number;
  loginStatus?: "online" | "offline";
  takenOverEmployeeId?: string;
  /** 席位 AI 话术推荐能力是否开启，对应 `semiAutoAuth && semiAutoSwitch` */
  seatAIAssistantEnabled?: boolean;
  /** 席位群聊 AI 托管能力是否开启 */
  seatGroupAIHostingEnabled?: boolean;
  /** 席位群聊 AI 话术推荐能力是否开启 */
  seatGroupAIAssistantEnabled?: boolean;
  /** 席位业务状态：1 已绑定，0 已注销 */
  bizStatus?: number;
  /** 过期时间戳，单位：秒 */
  expireTime?: number;
};

export type Conversation = {
  id: string;
  /** 影子群会话暂不支持消息撤回 */
  isShadowGroup?: boolean;
  /** 会话 AI 托管开关，对应 `xy_wap_embed_conversation.full_auto_switch` */
  conversationAIHostingSwitch?: boolean;
  /** 转人工触发消息 ID；`0` 表示当前无接管提醒 */
  handoffMsgId: number;
  /** 当前会话最后一条审计消息 ID */
  lastMessageId?: number;
  /** 会话是否已经回复 */
  replied?: boolean;
  /** 托管状态栏展示状态 */
  agentHostingStatus?:
    | "active"
    | "exited"
    | "failed"
    | "generating"
    | "handoff"
    | "retrying"
    | "sendFailed"
    | "sendPartialFailed"
    | "sending"
    | "sent"
    | "thinking"
    | "waiting";
  accountId: string;
  /** 关联客户绑定或群席位业务状态；非 1 表示会话对象已失效 */
  bizStatus?: number;
  /** 客户绑定类型：1 普通客户，2 应用消息 */
  customerBindType?: number;
  customerId: string;
  customerName: string;
  customerAvatarUrl: string;
  /** 客户原始昵称（当使用备注展示时） */
  contactOriginalName?: string;
  /** 群原始名称（当使用备注展示时） */
  groupOriginalName?: string;
  createdAtMs?: number;
  preview: string;
  updatedAt: string;
  quietFor: string;
  unread: number;
  mode: ChatMode;
  priority: "high" | "medium" | "low";
  /** 三方用户 ID（侧栏 iframe 密文由服务端按会话签发） */
  thirdUserId?: string;
  /** 外部用户 ID（侧栏 iframe 密文由服务端按会话签发） */
  thirdExternalUserId?: string;
  /** 群会话三方群 ID，侧栏 iframe 在群聊时拼入查询参数 `qd` */
  thirdGroupId?: string;
  isPinned?: boolean;
  isVerified?: boolean;
  updatedAtMs?: number;
};

export type MessageSender = {
  groupMemberId?: string;
  id: string;
  name: string;
  avatarUrl?: string;
  userId?: string;
};

export type SystemMessageContent = {
  type: "system";
  text: string;
};

export type RevokeMessageContent = {
  revokeMsgId?: string;
  revokeOriginMsgId?: string;
  type: "revoke";
  text: string;
};

export type TextMessageContent = {
  type: "text";
  text: string;
};

export type VoiceMessageContent = {
  type: "voice";
  audioUrl?: string;
  durationLabel: string;
  playbackUrl?: string;
  transFileUrl?: string;
  transFileUrlPersisted?: boolean;
  transVoiceText?: string;
};

export type VoiceCallMessageContent = {
  type: "voice-call";
  text: string;
  missed?: boolean;
};

export type ImageMessageContent = {
  type: "image";
  imageUrl: string;
  alt: string;
  downloadStatus?: MessageFileDownloadStatus;
  fileSerialNo?: string;
  variant?: "image" | "emotion";
  width?: number;
  height?: number;
};

export type MessageFileDownloadStatus = "ing" | "finished" | "failed";

export type VideoMessageContent = {
  type: "video";
  videoUrl: string;
  coverImageUrl: string;
  alt: string;
  durationLabel: string;
  downloadStatus?: MessageFileDownloadStatus;
  fileSerialNo?: string;
  fileUrlExpireTime?: number;
  width?: number;
  height?: number;
};

export type FileMessageContent = {
  type: "file";
  fileName: string;
  fileSizeLabel?: string;
  extension: string;
  downloadStatus?: MessageFileDownloadStatus;
  fileSerialNo?: string;
  fileUrl?: string;
  sourceLabel?: string;
};

export type H5CardMessageContent = {
  type: "h5";
  title: string;
  description: string;
  url?: string;
  previewImageUrl?: string;
  sourceLabel?: string;
};

export type MiniProgramMessageContent = {
  type: "mini-program";
  title: string;
  appName: string;
  coverImageUrl?: string;
  logoUrl?: string;
  sourceLabel?: string;
};

export type ContactCardMessageContent = {
  type: "contact-card";
  name: string;
  avatarUrl?: string;
  company?: string;
  contactSerialNo?: string;
  groupSerialNo?: string;
  sourceLabel?: string;
};

export type LocationMessageContent = {
  type: "location";
  title: string;
  address: string;
  latitude?: number;
  longitude?: number;
  zoom?: number;
};

export type SphFeedMessageContent = {
  type: "sphfeed";
  title: string;
  description: string;
  imageUrl?: string;
  url?: string;
  sourceLabel?: string;
};

export type SolitaireMessageItem = {
  content: string;
  memberSerialNo?: string;
  timestamp?: number;
};

export type SolitaireMessageContent = {
  type: "solitaire";
  title: string;
  example?: string;
  items: SolitaireMessageItem[];
  tail?: string;
  createMemberSerialNo?: string;
};

export type RedPacketMessageContent = {
  type: "redpacket";
  title: string;
  description: string;
  totalAmount?: number;
  totalCnt?: number;
};

export type QuotedMessagePreviewContent = {
  contentType: WorkbenchMessageContentType;
  fallbackText?: string;
  imageUrl?: string;
  quoteMsgId?: string;
  senderName: string;
  text?: string;
  title?: string;
};

export type QuoteMessageContent = {
  type: "quote";
  text: string;
  quoteMsgId: string;
  quotedMessage?: QuotedMessagePreviewContent;
};

export type ChatRecordMessageContent = {
  type: "chatrecord";
  msgTitle: string;
  msgContent: string[];
  unsupportedDisplayText?: string;
  viewState?: "loading";
};

export type MessageContent =
  | SystemMessageContent
  | RevokeMessageContent
  | TextMessageContent
  | VoiceMessageContent
  | VoiceCallMessageContent
  | ImageMessageContent
  | VideoMessageContent
  | FileMessageContent
  | H5CardMessageContent
  | MiniProgramMessageContent
  | ContactCardMessageContent
  | LocationMessageContent
  | SphFeedMessageContent
  | SolitaireMessageContent
  | RedPacketMessageContent
  | QuoteMessageContent
  | ChatRecordMessageContent;

type BaseMessage = {
  uiMessageKey: string;
  msgid?: string;
  conversationId: string;
  createdAtMs?: number;
  role: MessageRole;
  author: string;
  sentAt: string;
  updatedAtMs?: number;
  status: MessageStatus;
  isNew?: boolean;
  optNo?: string;
  /** 仅用于将无 optNo 的服务端回写与本地乐观消息对账 */
  reconcileFingerprint?: string;
  rawMsgtype?: string;
  seq?: number;
  source?: number;
  failReason?: string;
  isRevoked?: boolean;
  revokePending?: boolean;
};

export type SystemMessage = BaseMessage & {
  role: "system";
  content: SystemMessageContent | RevokeMessageContent;
};

export type ChatMessage = BaseMessage & {
  role: "customer" | "agent";
  sender: MessageSender;
  avatarOrnamentUrl?: string;
  isGroupConversation?: boolean;
  isAgentMessage?: boolean;
  isOwnMessage?: boolean;
  senderDisplayName?: string;
  content:
    | TextMessageContent
    | VoiceMessageContent
    | VoiceCallMessageContent
    | ImageMessageContent
    | VideoMessageContent
    | FileMessageContent
    | H5CardMessageContent
    | MiniProgramMessageContent
    | ContactCardMessageContent
    | LocationMessageContent
    | SphFeedMessageContent
    | SolitaireMessageContent
    | RedPacketMessageContent
    | QuoteMessageContent
    | ChatRecordMessageContent;
};

export type Message = SystemMessage | ChatMessage;

export type CustomerProfile = {
  id: string;
  name: string;
  avatarUrl: string;
  persona: string;
  city: string;
  phone: string;
  stage: string;
  intentScore: number;
  tags: string[];
  metrics: Array<{
    label: string;
    value: string;
  }>;
  tasks: Array<{
    id: string;
    title: string;
    status: "open" | "due" | "done";
  }>;
  notes: string[];
};
