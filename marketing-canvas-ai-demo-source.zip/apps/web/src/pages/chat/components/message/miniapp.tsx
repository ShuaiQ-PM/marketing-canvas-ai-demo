import { AiBrowserIcon } from "@hugeicons/core-free-icons";
import { HugeiconsIcon } from "@hugeicons/react";
import type { SVGProps } from "react";
import { cn } from "@/lib/utils";
import type { MiniProgramMessageContent } from "@/pages/chat/chat-types";
import {
  LoadableMessageImage,
  MessageMediaFallback,
} from "@/pages/chat/components/message/media-fallback";

const MINI_PROGRAM_APP_NAME_MAX_LENGTH = 18;
const MINI_PROGRAM_TITLE_MAX_CHARS_PER_LINE = 16;

type MiniAppMessageCardProps = {
  className?: string;
  content: MiniProgramMessageContent;
  footerNote?: string;
  titleLines?: 1 | 2;
};

export function MiniAppMessageCard({
  className,
  content,
  footerNote,
  titleLines = 2,
}: MiniAppMessageCardProps) {
  const coverImageUrl = content.coverImageUrl?.trim();
  const normalizedFooterNote = footerNote?.trim();
  const displayAppName = truncateMiniProgramText(
    content.appName,
    MINI_PROGRAM_APP_NAME_MAX_LENGTH,
  );
  const displayTitle = truncateMiniProgramText(
    content.title,
    titleLines * MINI_PROGRAM_TITLE_MAX_CHARS_PER_LINE,
  );

  return (
    <div
      className={cn(
        "w-[240px] rounded-[8px] border border-border bg-surface p-2.5 pb-1.5",
        className,
      )}
      data-testid="mini-program-message-card"
    >
      <div className="flex min-w-0 items-center gap-1.5 text-[12px] text-muted-foreground">
        <div className="flex size-4 items-center justify-center rounded-full bg-primary/10 text-primary">
          {content.logoUrl ? (
            <img
              alt={content.appName}
              className="size-full rounded-full object-cover"
              loading="lazy"
              src={content.logoUrl}
            />
          ) : (
            <HugeiconsIcon icon={AiBrowserIcon} size={14} strokeWidth={1.9} />
          )}
        </div>
        <span
          className="min-w-0 truncate font-medium"
          data-testid="mini-program-app-name"
          title={content.appName}
        >
          {displayAppName}
        </span>
      </div>

      <div className="mt-2.5">
        <p
          className={cn(
            "text-[14px] font-medium leading-5 text-foreground",
            titleLines === 1 ? "line-clamp-1" : "line-clamp-2",
          )}
          title={content.title}
        >
          {displayTitle}
        </p>
      </div>

      <div className="mt-2.5 aspect-[5/4] overflow-hidden rounded-[4px] bg-surface-muted">
        {coverImageUrl ? (
          <LoadableMessageImage
            alt={content.title}
            className="block h-full w-full object-cover"
            fallback={<MiniProgramCoverFallback title={content.title} />}
            loading="lazy"
            src={coverImageUrl}
          />
        ) : (
          <MiniProgramCoverFallback title={content.title} />
        )}
      </div>

      <div className="mt-2.5 flex min-w-0 items-center gap-1 border-t border-divider pt-2 text-[11px] text-muted-foreground">
        {normalizedFooterNote ? (
          <span className="min-w-0 truncate" title={normalizedFooterNote}>
            {normalizedFooterNote}
          </span>
        ) : (
          <>
            <MiniProgramMark className="size-3.5 shrink-0 text-mini-program-brand" />
            <span className="min-w-0 truncate">{content.sourceLabel ?? "小程序"}</span>
          </>
        )}
      </div>
    </div>
  );
}

function truncateMiniProgramText(value: string, maxLength: number) {
  const characters = Array.from(value);

  if (characters.length <= maxLength) {
    return value;
  }

  return `${characters.slice(0, Math.max(0, maxLength - 3)).join("")}...`;
}

function MiniProgramCoverFallback({ title }: { title: string }) {
  return (
    <MessageMediaFallback
      className="flex h-full w-full items-center justify-center bg-muted-foreground/5 text-muted-foreground/30"
      iconSize={36}
      iconTestId="mini-program-cover-fallback-icon"
      label={`小程序封面不可用：${title}`}
    />
  );
}

export function MiniProgramMark({
  className,
  ...props
}: SVGProps<SVGSVGElement>) {
  return (
    <svg
      aria-hidden="true"
      className={cn("size-4", className)}
      data-testid="mini-program-mark"
      {...props}
      viewBox="0 0 1024 1024"
    >
      <g transform="translate(512 512) scale(1.5) translate(-512 -512)">
        <path
          d="M800 384a160.384 160.384 0 0 1-128.64 156.928 32 32 0 0 1-12.48-62.72A96 96 0 1 0 544 384v256a160 160 0 1 1-191.36-156.928 32 32 0 1 1 12.48 62.72A96 96 0 1 0 480 640V384a160 160 0 0 1 320 0z"
          fill="currentColor"
        />
      </g>
    </svg>
  );
}
