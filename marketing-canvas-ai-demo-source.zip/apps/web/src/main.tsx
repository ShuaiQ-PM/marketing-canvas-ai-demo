import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { WorkflowAiDemoPage } from "./pages/chat/workflow/workflow-ai-demo-page";
import "./styles/index.css";

const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element #root was not found.");

createRoot(rootElement).render(
  <StrictMode>
    <WorkflowAiDemoPage />
  </StrictMode>,
);
