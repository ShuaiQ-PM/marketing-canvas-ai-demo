export const demoEnabled = import.meta.env.DEV && import.meta.env.VITE_DEMO_MODE === "true";
