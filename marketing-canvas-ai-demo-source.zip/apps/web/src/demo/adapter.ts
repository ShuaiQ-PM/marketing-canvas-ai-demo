import type { AxiosAdapter } from "axios";
import seed from "./fixtures.json";
import routes from "./routes.json";
import * as kb from "./kb-data";

type Row = Record<string, unknown>;
const clone = <T,>(value: T): T => structuredClone(value);
const fixtures: Record<string, unknown> = clone(seed.fixtures);
const agents: Row[] = clone(seed.literals.mockAgents);
const agentDetails = new Map(agents.map((agent) => [String(agent.id), { ...clone(seed.literals.mockAgentDetail), ...agent } as Row]));
const tickets: Row[] = [0, 1, 2].map((index) => ({ ...clone(seed.literals.baseDetail.ticket), ticketId: String(501 + index), title: ["确认退款进度", "跟进客户补发需求", "确认产品使用方法"][index], customerName: ["王女士", "陈先生", "李女士"][index], createdAt: Date.now() - index * 3600000, updatedAt: Date.now(), customerAvatarUrl: "", ownerAccountAvatarUrl: "", canEdit: true, canDelete: true }));
export const demoUser = {
  accountType: "main" as const, displayName: "演示管理员", role: "owner" as const,
  permissions: ["chat.access", "chat.send", "chat.takeover", "settings.access", "settings.subAccounts.manage", "settings.managedAccounts.manage", "settings.sidebar.manage", "workflow_template_manage"] as const,
  subUserId: "sub-user-001", uid: 1,
};
function page(rows: Row[], params: URLSearchParams, key = "items") {
  const query = (params.get("query") ?? params.get("keyword") ?? "").toLowerCase();
  const filtered = rows.filter((row) => !query || JSON.stringify(row).toLowerCase().includes(query));
  const pageSize = Math.min(100, Math.max(1, Number(params.get("pageSize")) || 20));
  const current = Math.max(1, Number(params.get("page")) || 1);
  return { [key]: filtered.slice((current - 1) * pageSize, current * pageSize), page: current, pageSize, total: filtered.length, totalPages: Math.ceil(filtered.length / pageSize), pagination: { page: current, pageSize, total: filtered.length } };
}
const localValues = new Map<string, unknown>();
export function handleDemoRequest(method: string, rawUrl: string, body: Row = {}, query: Row = {}): unknown {
  const url = new URL(rawUrl, "http://demo.local");
  for (const [key, value] of Object.entries(query)) if (value != null) url.searchParams.set(key, String(value));
  const path = url.pathname.replace(/^\/api(?=\/)/, "");
  const params = url.searchParams;
  if (path === "/auth/session" || path === "/auth/refresh") return { subUser: clone(demoUser) };
  if (path === "/auth/logout") return { success: true };
  if (path === "/server/tickets/counts") return { assignedToMeActive: tickets.filter(t => t.status === "open").length, unassigned: 2 };
  if (path === "/server/tickets") {
    if (method === "POST") { const ticket = { ...tickets[0], ...body, ticketId: crypto.randomUUID(), createdAt: Date.now() }; tickets.unshift(ticket); return { ticket }; }
    return page(tickets.filter(t => !params.get("status") || t.status === params.get("status")), params);
  }
  if (path === "/server/insights/business/topics") {
    const dimension = String(params.get("dimension") ?? "intent");
    const topicNames: Record<string, string> = { intent: "物流异常", entity: "白色羽绒服", tag: "高意向客户", asset: "春季上新活动" };
    const name = topicNames[dimension] ?? topicNames.intent;
    return { dimension, topics: [{ code: "demo-1", dimension, mentionCount: 38, name, sessionCount: 29, share: 0.42, type: dimension === "entity" ? "product" : "" }], totals: { mentionCount: 38, topicSessions: 29 }, trend: [{ date: "2026-10-22", assetMentions: 8, entityMentions: 12, intentMentions: 38, tagMentions: 15, topicSessions: 29 }], intentTrend: [{ date: "2026-10-22", intentId: "demo-1", intentName: name, sessionCount: 29 }] };
  }
  const ticketMatch = path.match(/^\/server\/tickets\/([^/]+)(?:\/(.+))?$/);
  if (ticketMatch) {
    const ticket = tickets.find(t => t.ticketId === ticketMatch[1]);
    if (!ticket) throw new Error("演示工单不存在");
    const action = ticketMatch[2];
    if (!action && method === "DELETE") { tickets.splice(tickets.indexOf(ticket), 1); return { deleted: true }; }
    if (method === "PATCH" || action === "claim") Object.assign(ticket, body, { updatedAt: Date.now() }, action === "claim" ? { assignee: { displayName: demoUser.displayName, subUserId: demoUser.subUserId } } : {});
    if (!action || action === "claim") return { ticket: clone(ticket) };
    if (action === "activities") return { items: [{ activityId: "demo-activity", activityType: "created", content: null, createdAt: ticket.createdAt, detail: null, operator: { displayName: demoUser.displayName, subUserId: demoUser.subUserId }, operatorType: "human", ticketId: ticket.ticketId }], hasMore: false, nextCursor: null };
    if (action === "comments") return { activity: { activityId: crypto.randomUUID(), activityType: "commented", content: String(body.content ?? "演示备注"), createdAt: Date.now(), detail: null, operator: { displayName: demoUser.displayName, subUserId: demoUser.subUserId }, operatorType: "human", ticketId: ticket.ticketId } };
    if (action === "context") return { contextAccess: "allowed", context: { kind: "session", messages: [], hasMore: false, nextCursor: null, sessionId: "401" } };
    if (action === "assignee-options") return { items: [{ displayName: demoUser.displayName, subUserId: demoUser.subUserId }] };
  }
  if (path === "/server/ai-hosting/agents") {
    if (method === "GET") return page(agents, params, "agents");
    const agent = { ...clone(seed.literals.mockAgentDetail), ...body, id: crypto.randomUUID(), updatedAt: Date.now(), kbList: [], pendingSuggestionCount: 0, autoLearnEnabled: false };
    agents.unshift(agent); agentDetails.set(agent.id, agent); return clone(agent);
  }
  if (path === "/server/ai-hosting/agents/test") return clone(fixtures.testAiHostingAgent);
  const agentMatch = path.match(/^\/server\/ai-hosting\/agents\/([^/]+)(?:\/(name|auto-learn|publish|restore))?$/);
  if (agentMatch) {
    const agent = agentDetails.get(agentMatch[1]);
    if (!agent) throw new Error("演示智能体不存在");
    if (method === "DELETE") { agents.splice(agents.findIndex(a => a.id === agent.id), 1); agentDetails.delete(agentMatch[1]); return { deleted: true }; }
    if (method !== "GET") {
      Object.assign(agent, body, { updatedAt: Date.now() });
      if (agentMatch[2] === "publish") Object.assign(agent, { publishedAt: Date.now(), hasUnpublishedChanges: false });
      Object.assign(agents.find(a => a.id === agent.id) ?? {}, agent);
    }
    return clone(agent);
  }
  if (path === "/server/ai-hosting/kbs") {
    if (method === "GET") return kb.createMockKbListResponse(params.get("query") ?? undefined);
    const item = kb.addMockKbListItem({ name: String(body.name), description: String(body.description ?? "") }); return { kb: kb.createMockKbItem(item.id) };
  }
  const kbMatch = path.match(/^\/server\/ai-hosting\/kbs\/([^/]+)(?:\/(.+))?$/);
  if (kbMatch) {
    const [, id, action] = kbMatch;
    if (action === "docs") return kb.createMockKbDocsResponse(id, params.get("query") ?? undefined);
    if (action === "delete-check") return { canDelete: true, agents: [] };
    if (action === "delete") { kb.deleteMockKbListItem(id); return { deleted: true }; }
    if (action === "update") { kb.updateMockKbListItem(id, { name: String(body.name), description: String(body.description ?? "") }); return { kb: kb.createMockKbItem(id) }; }
    if (!action) return kb.createMockKbItem(id);
  }
  const docMatch = path.match(/^\/server\/ai-hosting\/kb-docs\/([^/]+)(?:\/(chunks))?$/);
  if (docMatch && method === "GET") return docMatch[2] ? kb.createMockKbDocChunksResponse(docMatch[1], params.get("query") ?? undefined) : kb.createMockKbDocDetail(docMatch[1]);
  if (path === "/server/settings/group-chats") return { items: [], groupChats: [], page: 1, pageSize: 20, total: 0, pagination: { page: 1, pageSize: 20, total: 0 } };
  if (method === "GET" && localValues.has(path)) return clone(localValues.get(path));
  if (method === "GET" && path in fixtures) return clone(fixtures[path]);
  const route = routes.find(r => r.method === method && new RegExp(r.pattern).test(path));
  if (route && method === "GET") return clone(fixtures[route.fixture]);
  // Mutable singleton settings stay local for the lifetime of this page.
  if (["PUT", "PATCH"].includes(method) && ["/server/ai-hosting/hosting-settings", "/server/ai-hosting/user-memory/settings", "/server/insights/settings/feature-config"].includes(path)) {
    const target = path.replace("/user-memory/settings", "/user-memory/overview");
    const get = routes.find(r => r.method === "GET" && new RegExp(r.pattern).test(target));
    const value = { ...(localValues.get(target) ?? (get ? fixtures[get.fixture] : {})) as Row, ...body };
    localValues.set(target, value); return clone(value);
  }
  // Any remaining product request is still answered locally; keep a small per-path
  // memory store so basic settings forms remain demonstrable without backend access.
  if (method === "GET") {
    return clone(localValues.get(path) ?? { items: [], seats: [], subAccounts: [], managedAccounts: [], accounts: [], agents: [], models: [], kbs: [], docs: [], skills: [], categories: [], workflows: [], conversations: [], tickets: [], pagination: { page: 1, pageSize: 20, total: 0 }, page: 1, pageSize: 20, total: 0, totalPages: 0 });
  }
  if (["POST", "PUT", "PATCH"].includes(method)) {
    const value = { ...(localValues.get(path) as Row | undefined), ...body, ok: true, success: true };
    localValues.set(path, value);
    return clone(value);
  }
  if (method === "DELETE") { localValues.delete(path); return { ok: true, success: true, deleted: true }; }
  return { ok: true, success: true };
}
export const demoAdapter: AxiosAdapter = async (config) => {
  let data: unknown;
  try {
    const payload = typeof config.data === "string" ? JSON.parse(config.data) : config.data;
    data = { success: true, data: handleDemoRequest((config.method ?? "GET").toUpperCase(), config.url ?? "", payload ?? {}, config.params ?? {}) };
  } catch (error) {
    console.info("[本地演示]", config.method, config.url);
    data = { success: false, error: { code: "DEMO_UNAVAILABLE", message: error instanceof Error ? error.message : "演示操作失败" } };
  }
  return { config, data, status: 200, statusText: "OK", headers: {} };
};
