import { resolve } from "node:path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: { alias: [
    { find: "@chatai/workflow-engine/graph", replacement: resolve(import.meta.dirname, "../../packages/workflow-engine/dist/graph.js") },
    { find: "@chatai/contracts", replacement: resolve(import.meta.dirname, "../../packages/contracts/dist/index.js") },
    { find: "@", replacement: resolve(import.meta.dirname, "src") },
  ] },
  server: { host: "0.0.0.0" },
});
